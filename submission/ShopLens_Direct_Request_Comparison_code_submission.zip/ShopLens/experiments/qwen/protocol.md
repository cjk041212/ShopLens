# Qwen upgrade implementation contract

Root: [PRIVATE_PATH]/NLP-Coursework. New source staging: /private/tmp/nlp-qwen-build.
Never read old TileRAC/Coast. Never overwrite existing data, baseline features/models/results or old reports/PPT/ZIP.
No git commit, automation or school upload. One allocated GPU at a time; no GPU work on login node.

## Experiment

- Model Qwen/Qwen3-Embedding-0.6B, revision 97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3.
- Modes: qwen_frozen, qwen_semantic, qwen_preference.
- Domains baby,sports,clothing; independent full-pipeline seeds42,43,44 =>27 formal test records.
- Same old processed catalogs/events, strict temporal histories, full candidates/exclusions, user-macro metrics, <=5 low-interaction cohort.
- Frozen history input: base-Qwen item text embeddings + existing frozen CLIP image embeddings for all modes.
- Candidate input: base/semantic-LoRA/preference-LoRA text embeddings + same CLIP.
- This is explicitly an asymmetric two-tower experiment. Do not serve adapted candidate vectors as history inputs.
- Tokenization max_length256, truncation, left padding, official last-token pooling, L2 normalization; same train/export encoding. No new chunking.
- LoRA r8 alpha16 dropout0.05 q_proj/v_proj; BF16+SDPA on CUDA, no quantization/flash-attn dependency.

## Stages and fair comparison

1. Cache base-Qwen text+old CLIP once/domain. Read old features.npz; never modify it.
2. Per domain/seed, warm up identical asymmetric 128d ranker on all eligible train cases, max20epochs, AdamW lr1e-3 wd1e-4,batch256, validation full-catalog NDCG@10, patience3 after min5epochs. Share selected warmup head initialization across three modes.
3. Deterministically sample up to30000 eligible TRAIN behavioral cases with a matching positive review>=5words. Shared case identities/order/negative arrays in all three groups. Each case includes strictly earlier history and positive target; preference query must never contain target review.
4. Train two adaptation epochs in all modes, batch32, head lr1e-4 wd1e-4; LoRA lr2e-5 wd0.01. No gradient accumulation initially. Same random negative excluding all that user's TRAIN positives.
   frozen: cached base candidate features, BPR updates head only.
   semantic: live candidate encoder, BPR consumes detached text embeddings and updates head only; symmetric multi-positive InfoNCE over live positive document embeddings and cached base-Qwen review anchors updates LoRA only. Same-ASIN reviews/docs are positives, not false negatives.
   preference: BPR on live positive/negative candidate embeddings updates head and LoRA directly.
   Review anchors are precomputed from base Qwen and never trainable. Candidate texts receive no query instruction; optional fixed review instruction must be recorded.
5. At each adaptation epoch, encode full catalog with current candidate tower and evaluate full downstream validation NDCG@10. Select epoch1or2 by the SAME metric for all modes; do not use test metrics or semantic loss for selection. Retain training/gradient evidence even if performance degrades. Warmup epoch0 is not a selectable adaptation checkpoint.
6. Evaluate test exactly once per selected mode/seed with full old protocol; save full raw result and aggregate9records/domain. These are declared sampled-adaptation experiments with a full-input warmup and full evaluation; do not pretend the30000 adaptation budget is all data.

## Layout

artifacts/qwen/<domain>/base/features.npz: item_ids,text[N,1024],image[N,512] (+metadata JSON).
artifacts/qwen/<domain>/<mode>/seed<seed>/:
  candidate.npz: item_ids,text[N,1024] (selected checkpoint)
  models/<mode>.pt: {state_dict: ranker weights}, no Qwen/base feature tensors
  models/<mode>.json: scorer metadata below
  serving.npz: item_ids,history_item_vectors[N,128],candidate_item_vectors[N,128]
  adapter/: selected PEFT adapter when trainable
  training.json: warmup/2 adaptation validation curves, raw objective losses, sample/config hashes, gradient evidence, live/cache parity
  results.json, complete.json
artifacts/qwen/<domain>/results.json: all9 formal results, replaced atomically by identity(mode,split,seed)
experiments/qwen/: pinned model source, protocol/config, job environments/status/log references, progress.

Metadata keys: model,seed,family='qwen_candidate_lora',item_ids,items_sha256,events_sha256,data_audit,training_item_counts,embedding_dim128,max_history20,selected_epoch1or2,epochs2,max_examples30000,n_training_examples(actual adaptation sample),lr,weight_decay,features_metadata,serving_sha256,head_sha256,candidate_sha256,base_features_sha256,model_id,revision,objective,warmup,encoding_config,lora_config. Paths should be project-relative where possible.
Record selected adapter hash and both selected candidate+serving caches. Resume only with matching data/config hashes. Save optimizer/RNG at epoch/step boundaries; each stage completion atomic. Never regard a partial model as complete.

## Ownership / APIs

implement_data owns qwen_data.py and baseline_snapshot.py only initially.
qwen_data.build_data(root,domain,seed,adaptation_limit=30000,max_history=20) -> object with items,item_ids,texts,events,training_examples,validation_examples,adaptation_examples,train_positive_sets,audit,hashes. Adaptation example adds review string, and original temporal case fields. Matching reviews use (user_id,item_id,timestamp).
qwen_data.sample_negatives(examples,positive_sets,n_items,seed)->np.int64 vector.

implement_training owns qwen_text.py,qwen_models.py,qwen_pipeline.py and tests/test_qwen_training.py.
qwen_models.QwenHistoryRecommender has history/candidate projections+fusion and user_network (Linear128,GELU,Linear128). No persistent feature buffers. Methods item_vectors(),history_item_vectors(),user_vectors(histories,history_vectors=None), forward(histories,positive_indices,negative_indices,positive_text=None,negative_text=None). Raw live embeddings override candidate text for BPR gradient; history always base cache. Shared exported head geometry all modes.
qwen_pipeline.run_one(root,domain,seed,model_path,device='cuda',config=None)->writes all3 completed mode/seed artifacts/results. It must support skipping verified completed units and stage/epoch resumption; config includes max_length,lora settings,warmup/adaptation budgets. A smoke/pilot option is diagnostic and cannot enter formal matrix.
qwen_text exposes model loading, differentiable last-token embedding, batched inference export, adapter save/load; detailed signatures agent may choose, used only pipeline.

Root owns qwen_inference.py,qwen_evaluate.py, experiment/PBS orchestration, integration/tests and final reports.
qwen_inference exposes available_models,load_scorer,recommend,explain with same public signatures as old inference, but only qwen_* modes and independent artifact directory.
qwen_evaluate.evaluate_qwen(processed_dir,artifact_dir,model,seed,device='cuda',write=True) exports SAME old metric/protocol schema (plus qwen config); called by pipeline after selection.

implement_frontend owns ui.py and new UI tests. UI registry maps model id -> artifact path+backend. qwen seed42 path above. Preserve6 old choices. All qwen inference via shoplens.qwen_inference; never call old FittedScorer for qwen ids. Aggregate metrics read artifacts/qwen/domain/results.json. True target/loss/status visualization; no fabricated metrics.

All agents may read existing final source. Edit only owned files under staging. Notify root before changing shared APIs.
