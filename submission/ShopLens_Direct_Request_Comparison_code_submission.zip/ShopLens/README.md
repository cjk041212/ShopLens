# ShopLens — CLIP 多模态个性化推荐

EE6405 Natural Language Processing 课程项目。研究主线是商品文本表示与训练期评论语义适配，冻结CLIP图片特征作为附加模态消融，检验它们是否改善个性化排序。课程截止：2026-11-15 23:59（UTC+8，NTULearn 已核对）。

## 启动本地演示

在终端进入本目录并执行：

```bash
.venv/bin/python -m streamlit run app.py
```

浏览器访问命令输出的 `http://127.0.0.1:8501`。界面提供三域选品、模型对照、证据检查、真实实验指标。无正式工件时显示准备状态，不用随机结果替代。喜欢商品的先后顺序构成会话历史，最近20件进入编码，全部已选商品从推荐候选排除。

## 安装与测试

需要 Python 3.11 或以上。

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m pip install --no-deps -e .
.venv/bin/python -m pytest -q
```

本机已有独立 `.venv`。测试fixture与正式 `data/`、`artifacts/` 分离，fixture分数不计入实验。

## 数据

Amazon2014 5-core：Baby、Sports and Outdoors、Clothing Shoes and Jewelry。每域分别训练和评价。这是同一平台来源的三个领域基准，是否符合老师“三个数据集”的课程口径需在选题确认时明确。

官方目录：<https://mcauleylab.ucsd.edu/public_datasets/data/amazon/categoryFiles/>

可完整复现的统一准备命令：

```bash
.venv/bin/python scripts/prepare_data.py --download --domains baby sports clothing
```

该命令记录缺图、二次筛选，并自动生成可跨机器使用的相对图片路径。以下是分步调试示例（其他域把 `baby` 改为 `sports`、`clothing`）：

```bash
.venv/bin/python -m shoplens.data download --domain baby --raw-dir data/raw
.venv/bin/python -m shoplens.data prepare --domain baby --raw-dir data/raw --processed-dir data/processed/baby --images-dir data/images/baby --require-text --require-image
.venv/bin/python -m shoplens.data audit-images --processed-dir data/processed/baby --images-dir data/images/baby --all --download
.venv/bin/python -m shoplens.data prepare --domain baby --raw-dir data/raw --processed-dir data/processed/baby --images-dir data/images/baby --require-text --require-images
```

跨机器传输前将 `items.jsonl` 的图片路径转换为项目相对路径；已准备正式数据使用 `data/images/<domain>/<ASIN>.jpg`。元数据是抓取快照，不能保证描述在过去时点已可见。原始文件来源和SHA256、缺失比例、筛选规则、分位时间边界记录在审计文件。

## 模型与训练

- 图片：冻结 `openai/clip-vit-base-patch32`。
- 文本：`sentence-transformers/all-MiniLM-L6-v2`，基线冻结，适配版微调最后两个Transformer block。
- 推荐器：128维商品投影/融合，最近20件商品的均值历史与MLP，BPR成对排序损失。
- 六方法：Popularity、BPR商品因子＋history ridge fold-in、TF-IDF、MiniLM文本推荐、CLIP＋MiniLM、CLIP＋适配MiniLM。

正式执行需使用已分配计算资源，不在集群登录节点进行模型编码、训练或评测。单卡顺序执行：

```bash
.venv/bin/python scripts/run_experiments.py --device cuda --domains baby sports clothing --seeds 42 43 44 --epochs 5 --adapt-epochs 2 --resume
```

`--resume`核验数据/特征/训练配置指纹，配置不一致时明确报错。每seed分别归档，UI固定使用预声明seed42，测试分数不参与选seed。适配模型固定seed42，下游推荐器重复42/43/44。

`train.pbs` 是本次已核实HPCC环境的作业模板，申请1张GPU、55分钟、8CPU、32GB内存，经 `gpu_free` 路由。再次运行应重新核对资源政策与免费额度。模板不含SSH凭据或私钥。

## 评价

全局时间0.8/0.9分位切分；评分>=4为正反馈；严格更早的历史；同时间戳互不可见；测试时权重固定，但先前发生的测试反馈可成为之后历史（prequential）。在统一保留完整目录中排名并排除全部已见正反馈；按用户宏平均Recall/NDCG@10/@20。低交互组按训练期正反馈用户数<=5定义，不能直接称为严格冷启动。

所有真实指标来自 `artifacts/<domain>/results.json`；模型检查点按验证集NDCG@10选优。主表固定5个推荐训练epoch，不等于各方法已充分调优。代码拒绝数据或特征变化后继续评旧模型。静态目录是统一评测假设，不等价真实线上商品上架过程。

## 结果与交付物

```bash
.venv/bin/python scripts/make_report.py
```

- `deliverables/实验报告.md`：真实统计、比较与限制。
- `deliverables/ShopLens_report_en.md`：英文研究报告，完整结果核验通过后生成。
- `deliverables/results_summary.csv`：按领域/方法汇总均值与标准差。
- `deliverables/ShopLens_presentation.pptx`：12页可编辑英文答辩幻灯片。
- `deliverables/ShopLens_human_narration.md`：真人录制使用，禁止AI配音。
- `deliverables/verification.json`：数据指纹、54条主结果、9个预算检查和作业完成证据。
- `deliverables/ui_validation.json`：真实三域、六方法的本机界面集成检查。
- `deliverables/贡献反思模板.md`：成员填写真实工作并签名。
- `deliverables/AI使用声明草稿.md`：依据课程要求补充完整、合规的记录链接并确认。

真人配音、组员实际贡献、签名以及正式提交需要由小组成员完成，不代填、不代签、不自动提交。此项目所在聊天含其他研究与账号背景，不应直接公开整个聊天作为课程记录。

## 目录

- `src/shoplens/`：数据、编码、适配、训练、评估、推理、界面。
- `tests/`：时序隔离、真实训练路径、工件完整性与模型一致性测试。
- `data/raw/`：官方原始数据及来源校验。
- `data/processed/`：统一图文目录、交互与审计。
- `artifacts/`：特征、适配模型、演示模型、测试结果。
- `experiments/runs/`：每领域每seed的检查点、记录。
- `materials/`：用户提供的课程要求材料。
- `deliverables/`：报告、汇总、幻灯片与提交材料草稿。

## 参考

CLIP <https://proceedings.mlr.press/v139/radford21a.html>；BPR <https://arxiv.org/abs/1205.2618>；Amazon <https://mcauleylab.ucsd.edu/public_datasets/data/amazon/datasets.html>；MiniLM <https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2>。

## 补充预算检查

主比较固定5epoch。针对MF在验证曲线末端仍改善的观察，另运行 `scripts/check_baseline_budget.py --device cuda --epochs 20`，同三个领域和推荐种子，验证集选优。结果保存在 `artifacts/budget_check/`，独立报告，不替换主比较。不同训练预算不能直接作为模型本身优劣的证据。
