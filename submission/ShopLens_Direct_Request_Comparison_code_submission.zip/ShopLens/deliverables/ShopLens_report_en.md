# ShopLens: Review-Adapted Language Representations for Multimodal Product Recommendation

## Abstract

ShopLens investigates how language representations affect personalized product ranking. The study compares a traditional TF-IDF representation, pretrained MiniLM sentence embeddings, and MiniLM adapted using training-period customer reviews. Frozen CLIP image embeddings provide an additional modality. Three Amazon product domains support a complete comparison of six methods with three downstream training seeds. An independent MF budget check separates the fixed primary training budget from longer optimization. The report combines ranking metrics, paired differences, sparse-item outcomes and measured local CPU inference. These experiments assess the implemented pipeline under a specific temporal protocol. They do not establish a general benefit from adding images or reducing a language-alignment loss.

## 1. Research question and language methods

Customer reviews describe products through experience, while catalogue descriptions emphasize specifications and promotional language. Our language question is whether adapting an encoder to connect these expressions improves subsequent recommendation. A separate comparison tests whether visual features add useful information beyond the text representation. This structure keeps NLP central: textual feature extraction, sentence representations and contrastive fine-tuning supply the main controlled changes. CLIP remains frozen throughout.

TF-IDF uses unigram and bigram product features with history cosine similarity. MiniLM-L6-v2 encodes product titles and descriptions into 384-dimensional vectors [3]. Long descriptions use 224-wordpiece chunks followed by normalized aggregation. Reviews never enter catalogue text. CLIP ViT-B/32 supplies a separate 512-dimensional image representation [2]. The learned ranker projects these inputs into a 128-dimensional product space. A small network converts the mean representation of recent liked products into a user vector. User–item dot products then rank the catalogue. A new session can use this same history encoder without learning a new user identifier.

## 2. Data and temporal evaluation

We use the Baby, Sports and Outdoors, and Clothing, Shoes and Jewelry domains of Amazon Reviews 2014 [1]. The table reports the final retained data, including readable product text and decodable photographs. Filtering can change the original five-core property. These are three domain benchmarks from one source, rather than independently collected corpora.

| Domain | Products | Users | Events | Train / validation / test events |
|---|---:|---:|---:|---:|
| Baby | 7,037 | 18,479 | 155,180 | 124,300 / 15,420 / 15,460 |
| Sports | 18,273 | 34,555 | 289,579 | 232,003 / 28,623 / 28,953 |
| Clothing | 22,491 | 36,437 | 255,681 | 204,767 / 25,620 / 25,294 |

Global timestamp quantiles at 0.8 and 0.9 define each domain’s training, validation and test intervals. Timestamp ties can change the exact record proportions. Ratings of four or five provide positive feedback. Every target uses only strictly earlier positive interactions, with at most twenty recent distinct products forming its history. Ranking excludes all previously liked products and skips repeat targets. Unobserved products are training contrasts, not verified dislikes.

Evaluation ranks the full retained catalogue. Model weights remain fixed, while earlier validation or test interactions may enter later histories under the prequential protocol. Each target has one relevant product. We calculate Recall and NDCG at ten and twenty, average within each user, and then average equally across users. Data fingerprints, evaluated cohorts and candidate protocols match across methods and seeds. Static metadata snapshots cannot reconstruct when historical descriptions first became available.

## 3. Training and adaptation

The primary learned recommenders use five training epochs, AdamW and BPR pairwise ranking loss [4]. Validation NDCG@10 selects the checkpoint. Popularity uses training counts and TF-IDF requires no iterative optimization. The behavioural baseline learns BPR item factors, then estimates a user vector through ridge history fold-in with regularization one. This inference rule differs from standard evaluation using learned user-ID embeddings. The primary table is a fixed-budget comparison, not an exhaustive tuning exercise.

Language adaptation updates MiniLM’s final two Transformer blocks for two epochs, with batch size thirty-two and at most thirty thousand positive training-period review–description pairs. A symmetric contrastive objective aligns paired texts. Each batch retains at most one pair per product. Adaptation validation holds out product identities within training-period pairs. The encoder seed remains forty-two. Seeds forty-two, forty-three and forty-four repeat downstream recommendation training only, so their variation excludes adaptation uncertainty.

| Domain | Training / validation pairs | Epoch 1 validation loss | Epoch 2 validation loss |
|---|---:|---:|---:|
| Baby | 27,087 / 2,913 | 0.531949 | 0.483126 |
| Sports | 26,784 / 3,216 | 0.525743 | 0.485004 |
| Clothing | 26,930 / 3,070 | 1.041855 | 0.956807 |

These losses measure semantic alignment after each adaptation epoch. We did not record a pre-adaptation validation baseline. An improvement between epochs therefore concerns this auxiliary objective and cannot establish that personalized ranking improved. Recommendation requires a separate downstream comparison.

## 4. Complete primary results

The complete six-method by three-domain matrix contains fifty-four test records. Cells show the mean and sample standard deviation over three downstream seeds. The four metric columns retain the same user-macro aggregation. Deterministic baselines can legitimately have zero between-seed deviation. No missing run or failed evaluation contributes a zero score.

| Domain | Method | NDCG@10 | Recall@10 | NDCG@20 | Recall@20 |
|---|---|---:|---:|---:|---:|
| Baby | Popularity | 0.008274±0.000000 | 0.018196±0.000000 | 0.013017±0.000000 | 0.037468±0.000000 |
| Baby | BPR + fold-in | 0.005395±0.000511 | 0.010466±0.001640 | 0.007192±0.000493 | 0.017677±0.001486 |
| Baby | TF-IDF | 0.007049±0.000000 | 0.013108±0.000000 | 0.008804±0.000000 | 0.020036±0.000000 |
| Baby | MiniLM | 0.008175±0.002764 | 0.017027±0.006002 | 0.011172±0.002870 | 0.029079±0.006572 |
| Baby | CLIP + MiniLM | 0.009619±0.000809 | 0.020532±0.001967 | 0.012573±0.001060 | 0.032207±0.002436 |
| Baby | CLIP + adapted MiniLM | 0.009688±0.000642 | 0.020784±0.002082 | 0.013246±0.000805 | 0.034910±0.001814 |
| Sports | Popularity | 0.005923±0.000000 | 0.011277±0.000000 | 0.007599±0.000000 | 0.018037±0.000000 |
| Sports | BPR + fold-in | 0.006849±0.000203 | 0.012240±0.000529 | 0.008346±0.000316 | 0.018180±0.000520 |
| Sports | TF-IDF | 0.013770±0.000000 | 0.024112±0.000000 | 0.016255±0.000000 | 0.033994±0.000000 |
| Sports | MiniLM | 0.005112±0.000380 | 0.009834±0.000894 | 0.006731±0.000605 | 0.016312±0.001837 |
| Sports | CLIP + MiniLM | 0.006329±0.000272 | 0.012405±0.000319 | 0.008228±0.000096 | 0.019981±0.000685 |
| Sports | CLIP + adapted MiniLM | 0.006962±0.000163 | 0.013571±0.000155 | 0.009057±0.000042 | 0.021936±0.000600 |
| Clothing | Popularity | 0.003162±0.000000 | 0.006561±0.000000 | 0.004436±0.000000 | 0.011603±0.000000 |
| Clothing | BPR + fold-in | 0.003058±0.000170 | 0.005414±0.000378 | 0.003645±0.000129 | 0.007766±0.000695 |
| Clothing | TF-IDF | 0.014282±0.000000 | 0.028114±0.000000 | 0.018100±0.000000 | 0.043353±0.000000 |
| Clothing | MiniLM | 0.003098±0.000175 | 0.006159±0.000400 | 0.004199±0.000149 | 0.010548±0.000645 |
| Clothing | CLIP + MiniLM | 0.003282±0.000274 | 0.006912±0.000608 | 0.004614±0.000518 | 0.012228±0.001609 |
| Clothing | CLIP + adapted MiniLM | 0.003485±0.000486 | 0.006959±0.000551 | 0.004825±0.000540 | 0.012294±0.000813 |

Under the primary budget, TF-IDF has higher mean NDCG@10 than all three neural variants in Sports, Clothing. This is a numerical comparison without a significance test.

Matched-seed differences below subtract the earlier method from the later method. They compare image addition and language adaptation separately. Positive, tied and negative counts preserve variation that an overall mean can conceal. Three optimization seeds are not independent samples of the user population and do not provide a significance test.

| Domain | Later minus earlier | ΔNDCG@10 mean±SD | Improved / tied / lower |
|---|---|---:|---:|
| Baby | Image addition | +0.001443±0.002120 | 2 / 0 / 1 |
| Baby | Review adaptation | +0.000070±0.000898 | 1 / 0 / 2 |
| Sports | Image addition | +0.001217±0.000108 | 3 / 0 / 0 |
| Sports | Review adaptation | +0.000633±0.000261 | 3 / 0 / 0 |
| Clothing | Image addition | +0.000184±0.000099 | 3 / 0 / 0 |
| Clothing | Review adaptation | +0.000203±0.000474 | 2 / 0 / 1 |

Adaptation improves NDCG@10 in 6 of nine matched domain–seed comparisons. The mixed directions do not support a stable recommendation gain.

## 5. Products with few interactions

The sparse group contains target products with at most five distinct positive training users, including zero-interaction products. It is not a dedicated strictly unseen-item cold-start experiment. The same cohort and threshold apply across methods. Its NDCG@10 results are:

| Domain | TF-IDF | MiniLM | CLIP + MiniLM | CLIP + adapted MiniLM |
|---|---:|---:|---:|---:|
| Baby | 0.007449±0.000000 | 0.000030±0.000052 | 0.000066±0.000113 | 0.000000±0.000000 |
| Sports | 0.016009±0.000000 | 0.000415±0.000115 | 0.000296±0.000174 | 0.000354±0.000120 |
| Clothing | 0.013973±0.000000 | 0.000895±0.000367 | 0.000491±0.000158 | 0.000392±0.000116 |

TF-IDF exceeds all three neural variants in this group for Baby, Sports, Clothing. This negative result prevents interpreting an aggregate change as evidence that the neural models solved sparse-product recommendation.

## 6. Independent MF budget sensitivity

MF validation curves continued rising near the five-epoch limit, motivating a separate twenty-epoch check for every domain and seed. This preserves the original primary table. Validation NDCG selects each extended checkpoint, with no selection by test performance. The table compares identical seeds, data and fold-in inference:

| Domain | Primary MF5 NDCG@10 | Independent MF20 NDCG@10 | Paired Δ mean±SD | Selected epochs |
|---|---:|---:|---:|---|
| Baby | 0.005395±0.000511 | 0.005563±0.000531 | +0.000168±0.000197 | 8,9,8 |
| Sports | 0.006849±0.000203 | 0.007069±0.000277 | +0.000220±0.000212 | 20,8,7 |
| Clothing | 0.003058±0.000170 | 0.003830±0.000308 | +0.000772±0.000162 | 17,20,18 |

Boundary checkpoints remain selected in Sports, Clothing, so the longer run does not demonstrate convergence. The check describes budget sensitivity rather than a new recommendation method. Neither five nor twenty epochs establishes exhaustive baseline tuning.

## 7. Local deployment and measured performance

The Streamlit interface supports product selection, matched-history model comparisons, rank changes and inspection of source descriptions and feature similarities. Similarities are diagnostic evidence, not causal explanations. Deployment reuses cached product vectors and small ranking networks, so the large encoders need not remain loaded.

Measured platform: macOS-27.0.1-arm64-arm-64bit, arm64, PyTorch 2.14.1, four CPU threads. The measurement process reached 714.6 MiB peak RSS. Each request selects three catalogue products and returns ten recommendations. 20 warm repetitions per method reuse the loaded scorer. Cold timing includes model loading and feature-checksum verification after Python and PyTorch imports.

| Domain | Method | Cold load + rank (ms) | Warm median (ms) | Warm P95 (ms) |
|---|---|---:|---:|---:|
| Baby | Popularity | 27.82 | 0.148 | 0.200 |
| Baby | BPR + fold-in | 67.52 | 0.730 | 0.942 |
| Baby | TF-IDF | 88.98 | 2.066 | 2.421 |
| Baby | MiniLM | 56.89 | 0.215 | 0.268 |
| Baby | CLIP + MiniLM | 88.71 | 0.192 | 0.233 |
| Baby | CLIP + adapted MiniLM | 90.14 | 0.192 | 0.256 |
| Sports | Popularity | 73.42 | 0.326 | 0.423 |
| Sports | BPR + fold-in | 161.78 | 2.830 | 3.049 |
| Sports | TF-IDF | 130.94 | 4.856 | 6.465 |
| Sports | MiniLM | 145.36 | 0.537 | 0.824 |
| Sports | CLIP + MiniLM | 236.27 | 0.561 | 1.073 |
| Sports | CLIP + adapted MiniLM | 226.88 | 0.541 | 1.161 |
| Clothing | Popularity | 116.86 | 0.428 | 0.765 |
| Clothing | BPR + fold-in | 217.52 | 3.532 | 3.777 |
| Clothing | TF-IDF | 170.60 | 1.624 | 2.082 |
| Clothing | MiniLM | 223.04 | 0.758 | 1.108 |
| Clothing | CLIP + MiniLM | 315.02 | 0.744 | 1.292 |
| Clothing | CLIP + adapted MiniLM | 304.54 | 0.817 | 1.149 |

These API timings exclude browser rendering, network transfer, encoder execution and application startup. Peak RSS belongs to the measurement process, not the whole desktop. The figures describe this workload and host, rather than a latency guarantee for arbitrary catalogues or devices.

## 8. Interpretation and limitations

The experiments distinguish semantic alignment from recommendation. A smaller contrastive validation loss concerns paired language representations, while user ranking also depends on interaction history, negative sampling and the scoring network. The sparse-item results and MF budget check constrain claims about model complexity.

The evaluation measures recorded positive-feedback prediction within one historical Amazon source. It cannot establish causal purchase effects, online satisfaction or robustness to future catalogue shifts. Three downstream seeds measure a limited part of training variation. Adding images also adds projection and fusion parameters; this is not a parameter-matched ablation, so differences cannot be attributed to image content alone. Further work should examine additional encoder seeds and validation-led hyperparameter budgets before extending conclusions. The delivered code, audits and run records support reproduction of this specific comparison.

## References

[1] [Amazon Reviews 2014, UCSD public data archive](https://mcauleylab.ucsd.edu/public_datasets/data/amazon/datasets.html).

[2] [Radford et al., Learning Transferable Visual Models From Natural Language Supervision, ICML 2021](https://proceedings.mlr.press/v139/radford21a.html). [Official CLIP implementation](https://github.com/openai/CLIP).

[3] [Sentence Transformers, all-MiniLM-L6-v2 model card](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2).

[4] [Rendle et al., BPR: Bayesian Personalized Ranking from Implicit Feedback, UAI 2009](https://arxiv.org/abs/1205.2618).

[5] [Streamlit documentation](https://docs.streamlit.io/).

Evidence snapshot: 2026-10-24 04:26:43 UTC+8. Sources: data/processed/*/audit.json, artifacts/*/results.json, artifacts/*/text_adaptation/adaptation.json, experiments/baseline_budget.json and artifacts/local_benchmark.json.
