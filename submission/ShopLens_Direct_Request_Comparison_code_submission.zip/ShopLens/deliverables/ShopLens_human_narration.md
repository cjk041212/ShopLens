# ShopLens human narration script

Record with a real group member’s voice. Presenter names and final contributions must be completed by the team.
Target duration: approximately 8–9 minutes including a short local demonstration. Rehearse once and keep the final recording below 10 minutes.

## Slide 1: ShopLens

Hello. Our project is ShopLens, a local product recommendation system that combines product photographs with language representations. We study whether visual information adds value beyond product text, and whether adapting a small text encoder with customer reviews improves recommendation. The interface lets a user select a few products and inspect how the resulting ranking changes across models. We evaluate the models separately on three Amazon product domains.

**Sources**

- https://mcauleylab.ucsd.edu/public_datasets/data/amazon/datasets.html
- https://proceedings.mlr.press/v139/radford21a.html
- https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2

## Slide 2: Research questions

The first question examines adding image features. We compare MiniLM text against a ranker with the same history module and latent size, plus a CLIP image branch. That branch adds trainable parameters, so this is not a capacity-matched comparison. The second question concerns language adaptation. A review describes a product in a customer’s own words, which may differ from its catalogue description. We adapt MiniLM to bring a review closer to the corresponding product text, and then test whether that representation helps recommendation. Neither question assumes that the more complex model must perform better.

**Sources**

- https://proceedings.mlr.press/v139/radford21a.html
- https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2
- src/shoplens/models.py
- src/shoplens/adapt.py

## Slide 3: Datasets

We use the Baby, Sports and Outdoors, and Clothing, Shoes and Jewelry domains from Amazon Reviews 2014. Each domain contains ratings and timestamps, while metadata links the products to descriptions and photographs. The table reads directly from the current data audit. It may show fewer records than the original five-core release because we require usable text and real, decodable images. The three domains provide separate benchmarks, although they come from the same source. The course instructor should confirm that this meets the requested dataset count.

**Sources**

- https://mcauleylab.ucsd.edu/public_datasets/data/amazon/datasets.html
- data/processed/baby/audit.json
- data/processed/sports/audit.json
- data/processed/clothing/audit.json

## Slide 4: Evaluation protocol

We split each domain using global timestamp quantiles rather than randomly mixing future and past interactions. Four- and five-star ratings count as positive feedback. For every target, the history contains only strictly earlier positive events and at most twenty recent distinct products. We rank the full prepared catalogue, excluding all previously liked products. Repeat targets are skipped. Test evaluation is prequential: earlier test interactions can become history for later targets, but the model weights never change. Equal timestamps do not enter a target’s history. We average each user’s target scores first, then average across users.

**Sources**

- src/shoplens/models.py
- src/shoplens/evaluate.py

## Slide 5: Representations

The image encoder is CLIP ViT-B/32. We freeze it and extract one vector from each real product photograph. MiniLM-L6-v2 provides a separate compact text representation. This separation makes the language work explicit and avoids relying on CLIP’s short text input for long descriptions. Catalogue encoding splits long text into chunks of two hundred and twenty-four wordpieces and aggregates their normalized vectors. Catalogue text contains only the title and description. Reviews enter the separate language-adaptation task, and only training-period reviews can enter that task.

**Sources**

- https://proceedings.mlr.press/v139/radford21a.html
- https://github.com/openai/CLIP
- https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2
- src/shoplens/features.py

## Slide 6: Architecture

The recommendation network projects image and text features, combines them through a small fusion network, and normalizes the resulting product vector. The latent dimension is one hundred and twenty-eight. A user representation comes from mean pooling recent liked-product vectors followed by an MLP. The final score is a user–item dot product. Because this model conditions on product history instead of requiring a learned user ID, a new user can select products in the interface and immediately receive recommendations through the same scoring code. The text-only ablation removes the image input while keeping the remaining architecture comparable.

**Sources**

- src/shoplens/models.py
- src/shoplens/inference.py

## Slide 7: Training objectives

Recommendation training uses a scaled BPR loss. A positive interaction should receive a higher score than a sampled unobserved item. We exclude the user’s observed training positives from the negative pool. Unobserved items are a training contrast, not verified dislikes. Validation NDCG selects the recommendation checkpoint without consulting test labels. For language adaptation, we fine-tune the last two MiniLM blocks using a symmetric contrastive loss between reviews and their corresponding product descriptions. Each batch keeps at most one pair per product to reduce obvious false negatives. Adaptation validation uses held-out products drawn only from training-period review pairs.

**Sources**

- https://arxiv.org/abs/1205.2618
- src/shoplens/train.py
- src/shoplens/adapt.py

## Slide 8: Controlled comparisons

We compare six methods under a fixed five-epoch primary training budget. Popularity and TF-IDF require no iterative training. The behavioural baseline learns product factors through BPR, then generates a user vector from history using a fixed ridge fold-in solution. This differs from standard user-ID matrix-factorization evaluation. MiniLM introduces semantic text features, CLIP adds images, and the final model changes the text representation through review adaptation. All methods share the cleaned catalogue and temporal protocol. Three seeds repeat downstream recommendation training with the adapted encoder fixed. A separate twenty-epoch MF sensitivity check examines the short primary budget and selects checkpoints through validation only.

**Sources**

- https://arxiv.org/abs/1205.2618
- src/shoplens/train.py
- src/shoplens/inference.py
- experiments/baseline_budget.json

## Slide 9: Ranking quality

This chart reads the test scores directly from the saved result files under the fixed five-epoch primary budget. It shows user-macro NDCG at ten for each domain. Missing bars indicate pending results. MiniLM against CLIP plus MiniLM addresses the image question. The two multimodal variants address adaptation. Review adaptation shows mixed outcomes: NDCG at ten improves in 6 of 9 completed domain-and-seed pairs. This does not establish a stable gain. The next slide reports variation and the separate baseline-budget check. These measurements do not establish online business impact.

**Sources**

- artifacts/baby/results.json
- artifacts/sports/results.json
- artifacts/clothing/results.json

## Slide 10: Local demonstration

For the demonstration, choose a product domain and select three to five liked products. The interface recalculates recommendations from the trained model, excluding the selected products. In the model-comparison view, keep the same input history and inspect the top-ranked products. The table reports actual rank changes within the displayed top-K lists. In the evidence view, inspect the original descriptions and similarities to the selected history. Those similarities help us diagnose results, but they are not causal explanations of the neural network. Finally, the experiment view shows saved metrics and the original audit records. The local application uses cached features and small models without keeping the large encoders loaded.

**Sources**

- src/shoplens/ui.py
- src/shoplens/inference.py

## Slide 11: Outcomes and limits

Baby currently has the highest mean NDCG at ten for CLIP + adapted MiniLM, 0.0097, across 3 saved seed results. Sports & Outdoors currently has the highest mean NDCG at ten for TF-IDF, 0.0138, across 3 saved seed results. Clothing & Accessories currently has the highest mean NDCG at ten for TF-IDF, 0.0143, across 3 saved seed results. Multiple seeds provide a mean and sample standard deviation. A single seed shows only its measured score. The primary MF result has the same five-epoch budget as the neural recommenders and cannot represent a fully tuned baseline. An independent twenty-epoch check uses validation-only checkpoint selection. Detailed sensitivity results and sparse-item outcomes appear in these speaker notes. The domains share one Amazon source and static catalogue snapshots. Offline ranking predicts recorded positive feedback, without establishing purchase conversion or causal explanations.

**Sources**

- artifacts/baby/results.json
- artifacts/sports/results.json
- artifacts/clothing/results.json
- experiments/baseline_budget.json
- https://mcauleylab.ucsd.edu/public_datasets/data/amazon/datasets.html

**Additional discussion notes (not part of the timed narration)**

The main table uses a fixed five-epoch primary budget for trainable recommenders. Its MF row is not an extensively tuned baseline. The independent twenty-epoch MF check examines the limited budget after the five-epoch validation curves continued to rise. The check keeps the primary table intact and selects each checkpoint using validation NDCG only.

Baby independent MF twenty-epoch NDCG@10: 0.0056±0.0005 (n=3). Primary five-epoch MF: 0.0054±0.0005 (n=3). Mean difference over 3 paired seeds: 0.000168. Validation-selected epochs: 42: 8, 43: 9, 44: 8.

Baby adaptation improves NDCG@10 in 1/3 paired seeds. Mean paired change: 0.000070. Individual differences: 42: -0.000699, 43: 0.001056, 44: -0.000148.

Baby low-interaction mean NDCG@10: TF-IDF 0.007449 (n=3), MiniLM 0.00003002 (n=3), CLIP + MiniLM 0.00006552 (n=3), CLIP + adapted MiniLM 0.000 (n=3). The group contains products with at most five distinct training-positive users, including zero-interaction products. It does not isolate strictly unseen-item cold start.

Sports & Outdoors independent MF twenty-epoch NDCG@10: 0.0071±0.0003 (n=3). Primary five-epoch MF: 0.0068±0.0002 (n=3). Mean difference over 3 paired seeds: 0.000220. Validation-selected epochs: 42: 20, 43: 8, 44: 7.

Sports & Outdoors adaptation improves NDCG@10 in 3/3 paired seeds. Mean paired change: 0.000633. Individual differences: 42: 0.000334, 43: 0.000813, 44: 0.000752.

Sports & Outdoors low-interaction mean NDCG@10: TF-IDF 0.01601 (n=3), MiniLM 0.0004146 (n=3), CLIP + MiniLM 0.0002957 (n=3), CLIP + adapted MiniLM 0.0003541 (n=3). The group contains products with at most five distinct training-positive users, including zero-interaction products. It does not isolate strictly unseen-item cold start.

Clothing & Accessories independent MF twenty-epoch NDCG@10: 0.0038±0.0003 (n=3). Primary five-epoch MF: 0.0031±0.0002 (n=3). Mean difference over 3 paired seeds: 0.000772. Validation-selected epochs: 42: 17, 43: 20, 44: 18.

Clothing & Accessories adaptation improves NDCG@10 in 2/3 paired seeds. Mean paired change: 0.000203. Individual differences: 42: 0.000500, 43: 0.000453, 44: -0.000343.

Clothing & Accessories low-interaction mean NDCG@10: TF-IDF 0.01397 (n=3), MiniLM 0.0008953 (n=3), CLIP + MiniLM 0.0004908 (n=3), CLIP + adapted MiniLM 0.0003916 (n=3). The group contains products with at most five distinct training-positive users, including zero-interaction products. It does not isolate strictly unseen-item cold start.

The twenty-epoch check is a sensitivity analysis, not a second main table or evidence that MF has reached its optimal hyperparameters. Differences remain descriptive without a statistical significance test. Adaptation repeats vary the downstream recommendation seed while holding the adapted encoder fixed.

## Slide 12: References

Our references are the official Amazon data archive, the CLIP paper and implementation, the MiniLM model card, and the original BPR paper. The complete project includes data and feature checksums, training settings and saved evaluation records so the comparison can be reproduced. We keep the group contribution and AI disclosure documents separate for the team to review and complete accurately. The presentation requires human narration, and this package does not generate an artificial voice. Thank you.

**Sources**

- https://mcauleylab.ucsd.edu/public_datasets/data/amazon/datasets.html
- https://proceedings.mlr.press/v139/radford21a.html
- https://github.com/openai/CLIP
- https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2
- https://arxiv.org/abs/1205.2618
- https://ntulearn.ntu.edu.sg/ultra/courses/_2706623_1/file/_6190402_1?courseId=_2706623_1
