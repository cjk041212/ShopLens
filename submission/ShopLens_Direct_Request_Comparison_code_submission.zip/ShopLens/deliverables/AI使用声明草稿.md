# EE6405 AI Disclosure — 填写官方表格用草稿

状态：待小组人工核实与确认，不代替NTULearn官方Academic Integrity and AI Disclosure Form。

## 已使用的辅助

- 工具：Codex。
- 用途：讨论选题、整理公开资料、制定实验协议、生成与修改Python代码、协助调试和测试、实现本地UI、整理报告与英文演示材料。
- 迄今AI参与的阶段：ideation/research、planning/method、material/code execution、editing/optimization。
- 训练模型：公开CLIP ViT-B/32、MiniLM-L6-v2及项目自己的推荐器。它们的功能和数据来源需要在报告中引用，与编程AI辅助分别说明。
- 视频：按课程要求由真人录音。未合成AI配音。

## 需由成员补齐

1. 按官方表选择正确声明路径。若采用教师批准的第三方工具路径，填写真实工具名称、批准教师与课程要求的记录链接。
2. 官方表要求的完整、真实、未编辑交互记录不得用人为整理摘要冒充。当前聊天包含其他研究与账号背景，不能直接公开整条聊天；请先确认学校允许的记录提供方式与访问范围，再提供相应记录。
3. 填写全体成员姓名、学号、签名与日期。
4. 逐条核对公开文献、数据版本、训练与评价记录，并能解释模型和指标。
5. 确认最终视频、报告、贡献说明的表述与真实实验一致。

## 草拟说明（人工复核后调整）

We used Codex to assist with project ideation, methodological planning, Python implementation, debugging, interface development, and drafting presentation materials. We will independently review the generated code, verify the data sources and evaluation protocol, and check the experimental claims before submission. Dataset and pretrained-model sources are cited separately. The presentation narration will use our own voices. The signed disclosure and required interaction records will be supplied through the course's approved process.

以上英文保留将来时，因为成员尚未提供独立核验和签署的事实；完成后应据实际情况改写。
