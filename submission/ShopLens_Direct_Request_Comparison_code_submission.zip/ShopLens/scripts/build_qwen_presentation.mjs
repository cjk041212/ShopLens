/**
 * Build the independent, editable Qwen course deck from audited artifacts.
 *
 * <bundled node> scripts/build_qwen_presentation.mjs --root /path/to/project
 *   [--summary path/to/results_qwen_summary.json] [--output-dir path]
 *   [--ui-screenshot path/to/actual-qwen-ui.png] [--draft]
 *
 * Final builds require the report's complete 27-record audit and an actual UI
 * screenshot. --draft permits missing evidence and labels it explicitly.
 * This script never trains, downloads, submits, publishes, or changes baselines.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const argv = process.argv.slice(2);
const option = (name, fallback) => {
  const at = argv.indexOf(name);
  if (at < 0) return fallback;
  if (!argv[at + 1] || argv[at + 1].startsWith('--')) throw new Error(`Missing value for ${name}`);
  return argv[at + 1];
};
const isDraft = argv.includes('--draft');
const workspaceDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const root = path.resolve(option('--root', process.env.SHOPLENS_ROOT || workspaceDir));
const outputDir = path.resolve(option('--output-dir', path.join(workspaceDir, 'deliverables')));
const summaryPath = path.resolve(option('--summary', path.join(root, 'deliverables/results_qwen_summary.json')));
const screenshot = path.resolve(option('--ui-screenshot', path.join(root, 'deliverables/assets/qwen_comparison_screenshot.png')));
const runtime = process.env.SHOPLENS_RUNTIME_BASE || '';
const modules = process.env.RUNTIME_NODE_MODULES || path.join(runtime, 'node/node_modules');
const python = process.env.RUNTIME_PYTHON || path.join(runtime, 'python/bin/python3');
const skill = process.env.SHOPLENS_PRESENTATION_SKILL || '';
process.env.RUNTIME_NODE_MODULES = modules;
const runtimeRequire = createRequire(path.join(modules, '../package.json'));
const { Presentation, PresentationFile } = await import(pathToFileURL(runtimeRequire.resolve('@oai/artifact-tool')).href);
const { resolvePresentationFont, applyPresentationChartFont, finalizePresentation } = await import(pathToFileURL(path.join(skill, 'container_tools/artifact_tool_utils.mjs')).href);
const font = resolvePresentationFont();
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const buildDir = path.join(workspaceDir, '.qwen-presentation-build', stamp);
const validatedDir = path.join(workspaceDir, '.qwen-presentation-validated', stamp);
await fs.mkdir(buildDir, { recursive: true });
await fs.mkdir(validatedDir, { recursive: true });
await fs.mkdir(outputDir, { recursive: true });

const domains = ['baby', 'sports', 'clothing'];
const names = { baby: 'Baby', sports: 'Sports & Outdoors', clothing: 'Clothing & Accessories' };
const shortNames = { baby: 'Baby', sports: 'Sports', clothing: 'Clothing' };
const modes = ['qwen_frozen', 'qwen_semantic', 'qwen_preference'];
const labels = { qwen_frozen: 'Frozen', qwen_semantic: 'Semantic alignment', qwen_preference: 'Preference ranking' };
const colors = { qwen_frozen: '#546982', qwen_semantic: '#347CDB', qwen_preference: '#1A967B' };
const C = { ink: '#17243C', muted: '#586C7C', teal: '#347CDB', purple: '#1A967B', amber: '#BA7830', bg: '#F6F8FC', white: '#FFFFFF', line: '#DCE5E8' };
const source = {
  amazon: 'https://mcauleylab.ucsd.edu/public_datasets/data/amazon/datasets.html',
  qwen: 'https://huggingface.co/Qwen/Qwen3-Embedding-0.6B',
  qwenTraining: 'https://github.com/QwenLM/Qwen3-Embedding/blob/main/docs/training/SWIFT.md',
  lora: 'https://arxiv.org/abs/2106.09685',
  clip: 'https://proceedings.mlr.press/v139/radford21a.html',
  bpr: 'https://arxiv.org/abs/1205.2618',
};
const local = relative => path.join(root, relative);
async function json(filename, fallback = {}) {
  try { return JSON.parse(await fs.readFile(filename, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return fallback; throw error; }
}
async function exists(filename) { try { return (await fs.stat(filename)).isFile(); } catch { return false; } }
const finite = value => typeof value === 'number' && Number.isFinite(value);
const mean = values => values.reduce((sum, value) => sum + value, 0) / values.length;
const std = values => values.length > 1 ? Math.sqrt(values.reduce((sum, value) => sum + (value - mean(values)) ** 2, 0) / (values.length - 1)) : null;
const nf = value => finite(value) ? value.toLocaleString('en-US') : 'Pending';
const score = record => {
  if (!record || !finite(record['ndcg@10'])) return 'Pending';
  const value = record['ndcg@10'].toFixed(4);
  return record.n > 1 && finite(record['ndcg@10_std']) ? `${value} ± ${record['ndcg@10_std'].toFixed(4)}` : `${value} (n=1)`;
};
const signed = value => finite(value) ? `${value >= 0 ? '+' : '−'}${Math.abs(value).toFixed(5)}` : 'Pending';
const summary = await json(summaryPath);
const recoveryPath = local('experiments/qwen/recovery_note.json');
const localRecovery = await json(recoveryPath);
const stagedRecovery = await json(path.join(workspaceDir, 'recovery_note.json'));
const numericalRecovery = summary.verification?.execution_recovery?.numerical_recovery || localRecovery.numerical_recovery || stagedRecovery.numerical_recovery;
const backendNarration = numericalRecovery ? ' Clothing used MATH SDPA after a reproduced gradient failure. Earlier completed runs kept automatic dispatch. We claim no bitwise trajectory identity.' : '';
const backendDiscussion = numericalRecovery ? 'The recovery policy applies MATH SDPA only to live CUDA candidate training forward for all six Clothing LoRA units. Earlier completed Baby/Sports LoRA units keep automatic dispatch. Evaluation and cache encoding keep automatic dispatch. The objective, samples, learning rates and budget remain unchanged. The same clean state, batch and RNG reproduced nonfinite LoRA gradients under automatic dispatch, while MATH replay and a fresh prefix stayed finite. These observations do not establish a particular fused-kernel root cause, bitwise trajectory equality or a performance improvement. Cross-domain differences remain conditional on the numerical configurations.' : '';
const audits = {}, raw = {}, legacy = {};
const required = new Set(domains.flatMap(domain => modes.flatMap(mode => [42, 43, 44].map(seed => `${domain}/${mode}/${seed}`))));
const seen = new Set();
for (const domain of domains) {
  audits[domain] = await json(local(`data/processed/${domain}/audit.json`));
  if (audits[domain].synthetic === true) throw new Error(`Synthetic data rejected: ${domain}`);
  const document = await json(local(`artifacts/qwen/${domain}/results.json`));
  raw[domain] = (document.results || []).filter(row => row.split === 'test' && modes.includes(row.model));
  for (const row of raw[domain]) {
    const key = `${domain}/${row.model}/${row.seed}`;
    if (!required.has(key) || seen.has(key)) throw new Error(`Unexpected/duplicate Qwen identity: ${key}`);
    if (row.data_audit?.synthetic || row.features_metadata?.synthetic || row.run_protocol?.evaluation_subset) throw new Error(`Diagnostic result rejected: ${key}`);
    if (!finite(row['ndcg@10']) || ![1, 2].includes(row.selected_epoch)) throw new Error(`Invalid result/checkpoint: ${key}`);
    seen.add(key);
  }
  legacy[domain] = (await json(local(`artifacts/${domain}/results.json`))).results || [];
}
const audited = summary.complete === true && summary.verification?.complete === true && summary.raw_record_count === 27 && summary.verification?.expected_records === 27 && !(summary.verification?.errors || []).length && seen.size === 27;
const hasScreenshot = await exists(screenshot);
if (!isDraft && !audited) throw new Error('Final deck requires a complete, error-free 27-record results_qwen_summary.json plus all raw results. Run make_qwen_report.py first, or use --draft.');
if (!isDraft && !hasScreenshot) throw new Error('Final deck requires --ui-screenshot pointing to the actual new Qwen interface. Use --draft for an explicitly pending slide.');
function aggregate(domain, mode, subgroup = null) {
  const values = raw[domain].filter(row => row.model === mode).map(row => subgroup ? row[subgroup]?.['ndcg@10'] : row['ndcg@10']).filter(finite);
  return values.length ? { 'ndcg@10': mean(values), 'ndcg@10_std': std(values), n: values.length } : null;
}
function pairs(domain, mode) {
  const frozen = new Map(raw[domain].filter(row => row.model === 'qwen_frozen').map(row => [row.seed, row['ndcg@10']]));
  return raw[domain].filter(row => row.model === mode && frozen.has(row.seed)).map(row => ({ seed: row.seed, delta: row['ndcg@10'] - frozen.get(row.seed) }));
}
function verifySummary() {
  for (const domain of domains) for (const mode of modes) {
    const calculated = aggregate(domain, mode);
    const declared = (summary.results || []).find(row => row.domain === domain && row.model === mode);
    if (calculated && declared) {
      if (Math.abs(calculated['ndcg@10'] - declared['ndcg@10']) > 1e-12 || calculated.n !== declared.n_seeds) throw new Error(`Summary/raw disagreement: ${domain}/${mode}`);
      if (calculated.n > 1 && Math.abs(calculated['ndcg@10_std'] - declared['ndcg@10_std']) > 1e-12) throw new Error(`Summary/raw SD disagreement: ${domain}/${mode}`);
    } else if (audited) throw new Error(`Missing audited aggregate: ${domain}/${mode}`);
  }
}
verifySummary();
const evidence = summary.verification?.unit_evidence || {};
const pairNarrative = mode => {
  const values = domains.flatMap(domain => pairs(domain, mode));
  const wins = values.filter(row => row.delta > 1e-12).length;
  return values.length ? `${labels[mode]} exceeds frozen NDCG@10 in ${wins} of ${values.length} matched domain-and-seed comparisons.` : `${labels[mode]} has no completed matched comparison at this snapshot.`;
};
const strongest = domains.map(domain => {
  const records = modes.map(mode => ({ mode, score: aggregate(domain, mode) })).filter(row => row.score);
  records.sort((a, b) => b.score['ndcg@10'] - a.score['ndcg@10']);
  return records.length ? `${shortNames[domain]}: ${labels[records[0].mode]} has the highest observed mean, ${records[0].score['ndcg@10'].toFixed(4)}.` : `${shortNames[domain]}: formal results remain pending.`;
}).join(' ');

const p = Presentation.create({ slideSize: { width: 1280, height: 720 } });
const notes = [];
// Keep the timed narration short enough to leave room for a real live demo.
// Longer methodological details remain in discussion notes, never hidden from
// the presenter and never counted as part of the recording script.
const spoken = {
  'ShopLens': 'ShopLens studies whether adapting language representations improves multimodal recommendation. Product photographs provide an additional input, while the main experiment focuses on text. We compare frozen Qwen embeddings with two LoRA objectives: matching reviews to descriptions, and directly learning preference rankings. We then export compact vectors so that the demonstration can run on a local machine.',
  'Research question': 'A model can recognise that a review describes a product without learning what a particular user prefers next. The semantic arm matches review language to product descriptions. The preference arm learns to rank a liked product above an unobserved product, given earlier history. The experiment asks whether these objectives produce the same benefit on the recommendation metric. The model family and image features stay fixed.',
  'Datasets': 'We use three product domains from Amazon Reviews 2014. These are real reviews, catalogue descriptions and downloaded photographs. The table shows the cleaned data counts. Four- and five-star interactions count as positive feedback. Only training-period reviews supply semantic supervision. Product text contains the title and description. These are separate benchmarks from one data source, so the course instructor still needs to confirm that they satisfy the requested dataset count.',
  'Evaluation protocol': 'Each domain uses chronological training, validation and test splits. A target receives only strictly earlier positive history, with at most twenty recent distinct products. The model ranks the full prepared catalogue and excludes products already liked. Earlier held-out observations may enter later histories, but weights stay fixed. We average targets within each user, then average users. Validation selects the checkpoint. Test labels never select the model.',
  'Asymmetric architecture': 'The history path always receives frozen base-Qwen text and frozen CLIP images. The candidate path receives either base text or selected LoRA text, with the same images. Small projection and fusion networks produce separate one-hundred-and-twenty-eight-dimensional vectors. A user network pools history and scores candidates through a dot product. Frozen refers to the Qwen encoder. Its recommendation head still trains. Exported history and candidate caches preserve this distinction during local inference.',
  'Objectives and gradients': 'The frozen arm trains only the recommendation head with BPR. The semantic arm uses detached text vectors for BPR, while a separate contrastive loss updates LoRA by matching descriptions to frozen review anchors. Reviews of the same product count as multiple positives. The preference arm lets BPR update both the head and LoRA. It never uses the target review as a preference query. All arms keep the image encoder fixed.',
  'Training budget and checkpoint selection': 'Every domain and seed first trains a common head on all eligible cases. The three arms share that selected initialization. Adaptation uses the same thirty thousand review-matched cases, order and sampled negatives for two epochs. Full-catalogue validation NDCG selects epoch one or two in every arm. Warmup epoch zero cannot replace a poor adaptation result. Three complete pipeline seeds across three domains and three arms produce twenty-seven test records.',
  'Test ranking results': audited ? `These are actual test scores after validation-only selection. The chart shows mean user-macro NDCG at ten across three complete pipeline seeds. ${pairNarrative('qwen_semantic')} ${pairNarrative('qwen_preference')} The following slide checks variation rather than relying on a single best seed. These measurements describe offline ranking under this budget.` : 'The formal experiment remains incomplete. This draft therefore has no performance bars or ranking claim. The final deck requires all twenty-seven real records and a completed audit.',
  'Seed variation': 'The table shows means and sample standard deviations. Each paired change compares the same domain and seed, sharing initialization and adaptation cases. A win counts a positive metric difference. It does not mean statistical significance. Three seeds provide a limited view of variation. We retain settings where LoRA hurts, rather than silently replacing them with the warmup checkpoint.',
  'Sparse item results': 'This analysis groups targets with at most five distinct training-positive users, including zero. It asks where language representations may help when behavioural evidence is sparse. Every method still ranks the same full catalogue. The cohort mixes unseen products with products that have some interactions, so it does not establish strict item cold-start performance. The saved results retain cohort user and target counts.',
  'Local demonstration': 'The local interface displays real product photographs and accepts a short history of liked products. We hold that history fixed while comparing the three objectives. The screen shows ranked products, rank changes and actual saved metrics. It uses compact exported vectors, so the Qwen encoder stays outside the local recommendation path. Similarities and matching text provide diagnostic evidence, rather than causal explanations. I will now briefly demonstrate the same preference history across the three columns.',
  'Findings and limitations': audited ? `${pairNarrative('qwen_semantic')} ${pairNarrative('qwen_preference')} The earlier baselines remain available, but their different architecture and budget prevent attributing a score change to Qwen alone. The domains share one Amazon source, and static catalogue metadata limits historical realism. These offline observations do not establish online conversion or broad cold-start gains.${backendNarration} The main contribution is a controlled comparison of semantic and preference objectives, with a reproducible local demonstration. Our references are Amazon Reviews 2014, official Qwen documentation, and the original LoRA, CLIP and BPR papers. Thank you.` : 'The final conclusion depends on the audited matched comparisons. Earlier baselines remain available with their original budget. The domains share one Amazon source, and catalogue metadata comes from a static crawl. The current draft makes no performance claim.',
};
let sequence = 0;
function text(s, value, x, y, width, height, size = 28, color = C.ink, bold = false, extra = {}) {
  const shape = s.shapes.add({ geometry: 'textbox', name: `text-${++sequence}`, position: { left: x, top: y, width, height }, fill: 'none', line: { fill: 'none', width: 0 } });
  shape.text = value;
  shape.text.style = { typeface: font, fontSize: size, color, bold, verticalAlignment: 'top', wrap: 'square', autoFit: 'none', insets: 0, ...extra };
  return shape;
}
function slide(title, subtitle = null) {
  const s = p.slides.add();
  s.background.fill = C.bg;
  text(s, title, 72, 52, 1136, 75, 43, C.ink, true);
  if (subtitle) text(s, subtitle, 74, 135, 1130, 58, 25, C.muted);
  text(s, `${String(p.slides.items.length).padStart(2, '0')}  ShopLens`, 1060, 674, 148, 24, 17, C.muted, false, { alignment: 'right' });
  if (isDraft) text(s, 'DRAFT', 74, 674, 120, 23, 17, C.amber, true);
  return s;
}
function note(s, title, narration, citations = [], technical = '') {
  const detailed = [narration !== spoken[title] ? narration : '', technical].filter(Boolean).join('\n\n');
  const timed = spoken[title] || narration;
  s.speakerNotes.text = `${timed}${detailed ? `\n\nDiscussion notes outside timed narration\n${detailed}` : ''}\n\nSources\n${citations.join('\n')}`;
  notes.push({ title, narration: timed, citations, technical: detailed });
}
function table(s, values, y, height, widths, size = 25) {
  const tab = s.tables.add({ rows: values.length, columns: values[0].length, left: 72, top: y, width: 1136, height, values, columnWidths: widths });
  tab.styleOptions = { headerRow: true, bandedRows: false };
  tab.borders.assign({ style: 'solid', fill: C.line, width: 1 });
  tab.cells.block({ row: 0, column: 0, rowCount: values.length, columnCount: values[0].length }).assign({ fill: C.white, margins: { left: 15, right: 12, top: 11, bottom: 9 }, textStyle: { typeface: font, fontSize: size, color: C.ink } });
  tab.cells.block({ row: 0, column: 0, rowCount: 1, columnCount: values[0].length }).assign({ fill: C.ink, textStyle: { typeface: font, fontSize: size, color: C.white, bold: true } });
  return tab;
}
function pending(s, detail = 'The formal experiment has not completed its evidence audit.') {
  text(s, 'Results pending', 77, 263, 1120, 80, 55, C.teal, true);
  text(s, detail, 77, 380, 1110, 120, 30, C.muted);
}
function chart(s, subgroup = null) {
  const object = s.charts.add('bar', {
    position: { left: 72, top: 205, width: 1136, height: 385 },
    categories: domains.map(domain => shortNames[domain]),
    series: modes.map(mode => ({ name: labels[mode], values: domains.map(domain => {
      const value = aggregate(domain, mode, subgroup)?.['ndcg@10'];
      return finite(value) ? Number(value.toFixed(8)) : null;
    }), fill: colors[mode] })),
    hasLegend: true, legend: { position: 'bottom', textStyle: { fontSize: 24 } },
    barOptions: { direction: 'column', grouping: 'clustered', gapWidth: 90 },
    xAxis: { textStyle: { fontSize: 26, fill: C.ink }, majorGridlines: null },
    yAxis: { min: 0, numberFormatCode: subgroup ? '0.00000' : '0.000', textStyle: { fontSize: 23, fill: C.muted }, majorGridlines: { fill: C.line, width: 1 } },
    chartFill: 'none', plotAreaFill: 'none',
  });
  applyPresentationChartFont(object, { fontFamily: font });
  return object;
}

// 1. Minimal title. The deck makes no performance claim on the cover.
{
  const s = p.slides.add();
  s.background.fill = C.ink;
  text(s, 'ShopLens', 76, 118, 1100, 120, 83, C.white, true);
  text(s, 'Language adaptation for\nmultimodal recommendation', 78, 282, 1080, 160, 50, C.white);
  text(s, 'Qwen3-Embedding-0.6B with LoRA', 80, 507, 1100, 50, 30, '#A4E0D9');
  text(s, `EE6405 Natural Language Processing${isDraft ? '\nDraft with explicitly pending evidence' : ''}`, 80, 602, 1100, 65, 23, '#CBD9E1');
  note(s, 'ShopLens', 'ShopLens studies how language adaptation changes recommendation. We keep product photographs as an additional modality and focus on the text representation. The central experiment compares a frozen Qwen embedding model with two LoRA objectives. One aligns reviews with descriptions. The other trains directly for preference ranking. The trained system exports compact item vectors so that an interactive demonstration can run locally.', [source.qwen, source.lora, source.clip]);
}
// 2. A concrete research question and the language contribution.
{
  const s = slide('Semantic alignment and preference ranking');
  text(s, 'Does matching review language to product descriptions\nimprove the products we recommend?', 76, 189, 1120, 124, 39, C.ink, true);
  text(s, 'Semantic objective', 76, 373, 430, 48, 31, C.teal, true);
  text(s, 'A review and its product description\nshould have similar embeddings.', 76, 438, 513, 105, 29, C.muted);
  text(s, 'Recommendation objective', 676, 373, 520, 48, 31, C.purple, true);
  text(s, 'A product a user liked should outrank\nan unobserved product, given history.', 676, 438, 520, 105, 29, C.muted);
  text(s, 'The experiment tests whether these objectives produce the same ranking benefit.', 76, 603, 1120, 42, 26, C.ink);
  note(s, 'Research question', 'A model can understand that a review refers to a product without learning which product a particular user prefers next. We therefore separate semantic alignment from preference ranking. The semantic arm pairs a positive training review with its matching description. The preference arm uses the user’s earlier liked products to train a positive item above an unobserved item. All arms use the same Qwen model family and fixed image features. The question is empirical: under this controlled budget, does semantic improvement transfer to the recommendation metric, or does the ranking objective produce a different result?', [source.qwenTraining, source.bpr, local('src/shoplens/qwen_pipeline.py')]);
}
// 3. Native, editable counts from the real cleaned catalogs.
{
  const s = slide('Three Amazon product domains', 'Real reviews, catalogue descriptions and downloaded product photographs');
  table(s, [
    ['Domain', 'Products', 'Users', 'Interactions'],
    ...domains.map(domain => [names[domain], nf(audits[domain].counts?.items), nf(audits[domain].counts?.users), nf(audits[domain].counts?.events)]),
  ], 215, 280, [430, 216, 240, 250], 27);
  text(s, 'Text input: product title + description\nTraining supervision: observed positives and training-period reviews', 76, 542, 1120, 82, 28, C.ink);
  note(s, 'Datasets', 'The project uses three domains from the Amazon Reviews 2014 collection. We retain products with usable text and real, decodable product photographs. The table reads directly from the processed data audits. Four- and five-star interactions provide positive behavioural feedback. Training-period review text supplies semantic supervision. Catalogue text itself contains only the title and description. These are separate domain benchmarks from a single source. We must ask the course instructor whether that satisfies the required number of datasets, rather than calling them three independently sourced collections.', [source.amazon, ...domains.map(domain => local(`data/processed/${domain}/audit.json`))]);
}
// 4. Native split table avoids treating random samples as temporal validation.
{
  const s = slide('Chronological ranking protocol');
  table(s, [
    ['Training', 'Validation', 'Test'],
    ['First 80% time quantile', 'Next 10%', 'Final 10%'],
    ['Model fitting', 'Checkpoint selection', 'One selected-model evaluation'],
  ], 183, 235, [379, 378, 379], 26);
  text(s, 'Strictly earlier positive history. At most 20 recent distinct products.', 76, 468, 1120, 50, 29, C.ink, true);
  text(s, 'Full catalogue candidates exclude previous positives.\nAverage targets within each user, then average users.', 76, 548, 1120, 87, 29, C.muted);
  note(s, 'Evaluation protocol', 'Each domain uses global timestamp quantiles for training, validation and test. Timestamp ties stay in the earlier split, so record counts need not equal the nominal percentages exactly. A target uses only strictly earlier positive history, with at most twenty recent distinct products. Repeated targets that already occur in that history do not enter evaluation. We rank the complete prepared catalogue and exclude earlier positives. Scores use a stable item-ID tie rule. The evaluation is prequential: earlier observations within a held-out split may enter a later history, while model weights stay fixed. We average target scores within each user before calculating the user macro mean.', [local('src/shoplens/models.py'), local('src/shoplens/qwen_evaluate.py')]);
}
// 5. The asymmetric input constraint is central to fair local serving.
{
  const s = slide('Fixed history input and adapted candidate text');
  table(s, [
    ['Path', 'Text input', 'Image input'],
    ['Recent liked products', 'Frozen base Qwen, 1024d', 'Frozen CLIP, 512d'],
    ['Candidate products', 'Base Qwen or selected LoRA', 'Same frozen CLIP, 512d'],
  ], 192, 235, [350, 460, 326], 27);
  text(s, 'Separate projection + fusion networks produce 128-dimensional vectors.', 76, 472, 1120, 64, 29, C.ink, true);
  text(s, 'User vector = L2-normalize(MLP(mean(history vectors)))\nRanking score = user vector · candidate vector', 76, 563, 1120, 78, 29, C.muted);
  note(s, 'Asymmetric architecture', 'All three arms receive the same frozen base-Qwen history embeddings and frozen CLIP image embeddings. Only the candidate text representation changes across objectives. Separate small projection and fusion networks form history and candidate vectors. The user encoder mean-pools recent history vectors and applies an MLP. A dot product scores every candidate. The small ranking head can update in every arm, including frozen. Frozen therefore means a frozen Qwen encoder, not an untrained recommender. At export, we save history vectors and candidate vectors separately. The local interface must use the frozen-history path instead of accidentally using adapted candidate vectors as history.', [source.qwen, source.clip, local('src/shoplens/qwen_models.py'), local('src/shoplens/qwen_inference.py')]);
}
// 6. Native editable objective table states the gradient paths exactly.
{
  const s = slide('Three training objectives');
  table(s, [
    ['Arm', 'Recommendation head', 'Qwen LoRA update'],
    ['Frozen', 'BPR ranking loss', 'None'],
    ['Semantic alignment', 'BPR on detached text vectors', 'Review–description InfoNCE'],
    ['Preference ranking', 'BPR ranking loss', 'Same BPR ranking loss'],
  ], 196, 320, [325, 415, 396], 26);
  text(s, 'LoRA: rank 8, alpha 16, dropout 0.05, q_proj and v_proj\nAll paths retain the same frozen image embeddings.', 76, 561, 1120, 80, 27, C.muted);
  note(s, 'Objectives and gradients', 'The frozen arm updates the recommendation head using BPR while keeping Qwen fixed. The semantic arm runs live candidate embeddings, but detaches them for the ranking-head loss. Its separate symmetric contrastive loss updates LoRA by matching product descriptions to frozen review anchors from the base Qwen model. Reviews for the same product count as multiple positives, preventing them from becoming obvious false negatives. The preference arm lets the BPR gradient update both the ranking head and LoRA through positive and negative candidate text. We configure LoRA with rank eight, alpha sixteen and dropout zero point zero five on the query and value projections. The target review never enters the preference query.', [source.lora, source.qwenTraining, local('src/shoplens/qwen_text.py'), local('src/shoplens/qwen_pipeline.py')]);
}
// 7. Training budget and validation selection remain explicit.
{
  const s = slide('Shared initialization and adaptation budget');
  text(s, 'Common warmup', 76, 181, 430, 47, 32, C.teal, true);
  text(s, 'All eligible training cases. Up to 20 epochs with validation early stopping.\nEach domain and seed shares the same selected head across its three arms.', 76, 247, 1120, 104, 28, C.ink);
  text(s, 'Controlled adaptation', 76, 388, 700, 47, 32, C.purple, true);
  text(s, '30,000 matched training cases per domain and seed. Two epochs.\nIdentical case order and sampled negatives across the three arms.', 76, 454, 1120, 95, 28, C.ink);
  text(s, 'Full-catalogue validation NDCG@10 selects epoch 1 or 2.\nThree complete pipeline seeds per domain produce 27 formal test records.', 76, 579, 1120, 75, 27, C.muted);
  note(s, 'Training budget and checkpoint selection', 'For each domain and seed, we first train a common ranking head using every eligible training case. Warmup runs for at most twenty epochs, with patience three after at least five epochs, selecting through full-catalogue validation NDCG. Every objective starts from that same head. Adaptation then uses thirty thousand eligible training cases with matching positive review text. The case order and negative arrays match across arms. We run two adaptation epochs with batch size thirty-two. The head learning rate is one times ten to the minus four, and the LoRA learning rate is two times ten to the minus five. Every arm selects epoch one or two using the same downstream validation metric. Warmup epoch zero cannot replace a failed adaptation checkpoint. Test evaluation runs only after selection. Three seeds repeat the full pipeline, rather than only the final head.', [local('src/shoplens/qwen_data.py'), local('src/shoplens/qwen_pipeline.py'), summaryPath], 'The study uses a full-input warmup, sampled adaptation, and full evaluation. It does not claim that every eligible case enters the LoRA adaptation stage. Formal unit hashes record the common warmup, cases, order and negatives. The existing five-epoch MiniLM comparisons remain a separate earlier experiment with a different budget.');
}
// 8. Editable native chart, values from raw verified rows only.
{
  const s = slide('Test recommendation quality', 'User-macro NDCG@10. Mean across three complete pipeline seeds.');
  if (audited) {
    chart(s);
    text(s, 'All arms share the data, image features, initialization and adaptation samples.', 76, 619, 1120, 40, 25, C.muted);
  } else pending(s, `${seen.size} of 27 raw records are currently present.\nPerformance bars require the completed audit.`);
  note(s, 'Test ranking results', audited ? `The chart reports actual test NDCG at ten after validation-only checkpoint selection. ${strongest} ${pairNarrative('qwen_semantic')} ${pairNarrative('qwen_preference')} These are observations under the declared budget, rather than claims about online purchasing behaviour. The next slide reports seed variation and paired changes.` : 'The formal audit remains incomplete at this snapshot. This draft therefore contains no performance bars and no conclusion about the relative ranking quality. The final builder requires all twenty-seven real records, their completed checkpoint evidence, and an error-free report audit.', [summaryPath, ...domains.map(domain => local(`artifacts/qwen/${domain}/results.json`))]);
}
// 9. Native table shows uncertainty and matched comparisons without p-values.
{
  const s = slide('Variation across complete pipeline seeds', 'NDCG@10 mean ± sample standard deviation. Seeds 42, 43 and 44.');
  const values = [['Domain', 'Frozen', 'Semantic', 'Preference'], ...domains.map(domain => [shortNames[domain], ...modes.map(mode => audited ? score(aggregate(domain, mode)) : 'Pending')])];
  table(s, values, 211, 235, [260, 292, 292, 292], 25);
  const pairedLines = domains.map(domain => {
    const sem = pairs(domain, 'qwen_semantic'), pref = pairs(domain, 'qwen_preference');
    return audited ? `${shortNames[domain]}: semantic ${signed(mean(sem.map(row => row.delta)))} (${sem.filter(row => row.delta > 1e-12).length}/3 wins), preference ${signed(mean(pref.map(row => row.delta)))} (${pref.filter(row => row.delta > 1e-12).length}/3 wins)` : `${shortNames[domain]}: matched differences pending`;
  });
  text(s, 'Paired changes relative to Frozen', 76, 491, 1120, 43, 29, C.ink, true);
  text(s, pairedLines.join('\n'), 76, 550, 1120, 107, 26, C.muted);
  note(s, 'Seed variation', audited ? `${pairNarrative('qwen_semantic')} ${pairNarrative('qwen_preference')} The table reports sample standard deviation across the three independent pipeline seeds. We pair changes by domain and seed because the three arms share warmup and adaptation examples for that seed. A win means a positive metric difference, not a statistical significance result. With three seeds, these differences remain descriptive. We retain results where LoRA hurts rather than replacing them with the warmup checkpoint.` : 'The seed-variation table remains pending until all formal records pass the audit. The final version will show the mean, sample standard deviation, and paired changes relative to frozen for each domain. It will not turn a win count into a significance claim.', [summaryPath]);
}
// 10. A different cohort, not an unsupported strict cold-start claim.
{
  const s = slide('Products with few training interactions', 'Mean NDCG@10 for items with ≤5 distinct training-positive users, including zero');
  if (audited) {
    chart(s, 'low_interaction');
    const zeroDomains = domains.filter(domain => modes.every(mode => aggregate(domain, mode, 'low_interaction')?.['ndcg@10'] === 0));
    if (zeroDomains.length) text(s, `All three means are 0.00000 for ${zeroDomains.map(domain => shortNames[domain]).join(', ')}.`, 76, 599, 1120, 31, 24, C.muted);
    text(s, 'This cohort measures sparse-item ranking. It does not isolate strict unseen-item cold start.', 76, zeroDomains.length ? 636 : 616, 1120, 33, zeroDomains.length ? 23 : 25, C.muted);
  } else pending(s, 'Sparse-item scores require the same completed formal evaluation.');
  const detail = audited ? domains.map(domain => `${shortNames[domain]}: ${modes.map(mode => `${labels[mode]} ${score(aggregate(domain, mode, 'low_interaction'))}`).join(', ')}.`).join(' ') : '';
  note(s, 'Sparse item results', audited ? `We also report recommendation quality for products with at most five distinct positive users in the training period. This includes some zero-interaction products, but it combines them with products that do have training feedback. It therefore does not isolate strict item cold start. ${detail} The cohort uses the same full candidate catalogue as the primary evaluation. Its user and target counts appear in the raw saved results. These scores address where language information might matter, while retaining the same limitations of an offline observational dataset.` : 'The sparse-item analysis remains pending. The final chart will use the low-interaction fields produced by the same formal evaluation, rather than a separately sampled or easier candidate set. This cohort includes zero to five training-positive users and does not establish strict cold-start performance.', [summaryPath, local('src/shoplens/qwen_evaluate.py')]);
}
// 11. Exactly one actual UI screenshot, never a schematic or old proof image.
{
  const s = slide('Interactive comparison on a local machine');
  if (hasScreenshot) {
    const bytes = await fs.readFile(screenshot);
    const contentType = bytes[0] === 0xFF && bytes[1] === 0xD8 ? 'image/jpeg' : bytes[0] === 0x89 && bytes[1] === 0x50 ? 'image/png' : null;
    if (!contentType) throw new Error('The actual UI screenshot must be a PNG or JPEG.');
    s.images.add({ blob: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), contentType, alt: 'Actual new ShopLens Qwen comparison interface', fit: 'contain', position: { left: 70, top: 160, width: 770, height: 465 } });
    text(s, 'One preference history', 878, 206, 320, 83, 31, C.ink, true);
    text(s, 'Compare the three objectives\nand inspect rank changes.', 878, 326, 320, 120, 28, C.muted);
    text(s, 'Cached vectors keep the\nQwen encoder off the\nlocal inference path.', 878, 490, 320, 140, 28, C.teal);
  } else pending(s, 'An actual screenshot of the new Qwen comparison will replace this draft notice.\nNo previous baseline image represents the new experiment.');
  note(s, 'Local demonstration', 'The interface shows real product photographs and lets the audience choose a short preference history. The comparison keeps that history fixed across the frozen, semantic and preference arms. It displays ranked products, rank changes and saved evaluation metrics. Original baseline methods remain available as separate references. The local application loads the exported history and candidate vectors with the small ranking head, so it does not need to load the Qwen encoder to recommend. Feature similarities and matching text provide diagnostic evidence, rather than a causal explanation of the ranking. During a live demonstration, choose a few products and compare the three columns without changing the history.', [local('src/shoplens/ui.py'), local('src/shoplens/qwen_inference.py'), ...(hasScreenshot ? [screenshot] : [])]);
}
// 12. Evidence-driven conclusion and material limits, with references in notes.
{
  const s = slide('Findings and scope');
  text(s, audited ? pairNarrative('qwen_semantic') : 'The semantic-alignment comparison remains pending.', 76, 184, 1120, 92, 31, C.teal, true);
  text(s, audited ? pairNarrative('qwen_preference') : 'The preference-ranking comparison remains pending.', 76, 307, 1120, 92, 31, C.purple, true);
  text(s, 'The earlier baselines remain available. Their training budgets differ,\nso a new-versus-old score cannot isolate a Qwen model effect.', 76, numericalRecovery ? 428 : 448, 1120, 94, numericalRecovery ? 27 : 28, C.ink);
  if (numericalRecovery) {
    text(s, 'Clothing LoRA training used MATH SDPA after a reproduced gradient failure.\nEarlier completed runs kept automatic dispatch. Bitwise trajectories may differ.', 76, 528, 1120, 77, 25, C.muted);
    text(s, 'One Amazon source. Static metadata. Offline ranking cannot establish\nonline conversion, causal explanations or broad cold-start gains.', 76, 615, 1120, 52, 23, C.muted);
  } else text(s, 'Offline observational data. One Amazon source. Static catalogue metadata.\nNo claim of online conversion, causal explanations or broad cold-start gains.', 76, 575, 1120, 80, 27, C.muted);
  const baselineNotes = domains.map(domain => {
    const rows = legacy[domain].filter(row => row.split === 'test' && row.model === 'tfidf' && finite(row['ndcg@10']));
    return `${shortNames[domain]} preserved TF-IDF mean NDCG@10: ${rows.length ? mean(rows.map(row => row['ndcg@10'])).toFixed(6) : 'pending'} (${rows.length} records).`;
  }).join(' ');
  note(s, 'Findings and limitations', audited ? `The central finding is the measured relationship between a semantic objective and a preference objective. ${pairNarrative('qwen_semantic')} ${pairNarrative('qwen_preference')} ${strongest} We preserve the earlier six-method comparisons and independent MF budget check. Their architecture and training budget differ from this upgrade, so a score difference cannot establish that changing the text backbone alone caused an improvement. The three domains share a single Amazon source. Catalogue metadata comes from a static crawl whose historical availability is unknown. Our measurements predict recorded positive interactions and do not establish online purchase conversion. The human team must complete its genuine contribution statements and record the presentation in a real member’s voice. Thank you.` : 'No performance conclusion is available before the formal experiment completes. The final presentation will derive its findings from the audited matched comparisons. The project preserves the earlier baselines, but the new training budget prevents a clean causal claim about the text backbone alone. The domains share one Amazon source, and static catalogue metadata limits historical realism. The team must complete its genuine contribution statements and record the final presentation in a real member’s voice.', [source.amazon, source.qwen, source.qwenTraining, source.lora, source.clip, source.bpr, summaryPath, ...(numericalRecovery ? [recoveryPath] : [])], `${baselineNotes}\n\n${backendDiscussion}\n\nPrimary references: Amazon Reviews 2014 data archive, Qwen3-Embedding official model card and training documentation, Hu et al. (LoRA), Radford et al. (CLIP), Rendle et al. (BPR). Full URLs appear above. Statistical significance and online evaluation remain outside this study.`);
}

if (p.slides.items.length !== 12) throw new Error('Expected 12 slides.');
for (const [index, s] of p.slides.items.entries()) {
  const png = await p.export({ slide: s, format: 'png', scale: 1 });
  await fs.writeFile(path.join(buildDir, `slide-${String(index + 1).padStart(2, '0')}.png`), new Uint8Array(await png.arrayBuffer()));
}
const candidatePath = path.join(buildDir, 'candidate.pptx');
await (await PresentationFile.exportPptx(p)).save(candidatePath);
const basename = isDraft ? 'ShopLens_Qwen_presentation_DRAFT.pptx' : 'ShopLens_Qwen_presentation.pptx';
const finalPath = path.join(validatedDir, basename);
const nativeTableSlides = [3, 4, 5, 6, 9];
const result = await finalizePresentation({
  workspaceDir, candidatePath, finalPath, pythonExecutable: python,
  integrityValidatorPath: path.join(skill, 'container_tools/inspect_presentation_package_integrity.py'),
  layoutValidatorPath: path.join(skill, 'container_tools/inspect_presentation_layout_geometry.py'),
  layoutArgs: ['--expected-slide-size-emu', '12192000,6858000', '--validate-bullet-geometry', '--validate-heading-fit', ...nativeTableSlides.flatMap(number => ['--require-native-table-slide', String(number)])],
  explicitTotalSlideCount: 12,
  requiredNativeTableOwnerSlides: nativeTableSlides,
  requiredNativeChartOwnerSlides: audited ? [8, 10] : [],
  materializeLiteralChartWorkbooks: audited,
  fontPolicy: { basis: 'design', families: [font] },
  verifyArtifactToolImport: true,
  receiptPath: path.join(buildDir, 'validation.json'),
});
const deliveredPath = path.join(outputDir, basename);
await fs.copyFile(finalPath, deliveredPath);
const narrationPath = path.join(outputDir, isDraft ? 'ShopLens_Qwen_human_narration_DRAFT.md' : 'ShopLens_Qwen_human_narration.md');
const wordCount = notes.reduce((sum, entry) => sum + entry.narration.split(/\s+/).length, 0);
const humanScript = [
  '# ShopLens Qwen human narration script', '',
  'A real group member must record the narration. No artificial voice accompanies this deck.',
  'The entire recording must stay below 10 minutes, including slides, code, the UI demonstration, discussion, references and transitions.',
  'The formal narration is about 800–850 words, approximately 7–7.5 minutes at 110–120 words per minute. Results, limitations and the brief reference acknowledgement are already part of that narration.',
  'Reserve 90–120 seconds total for real operation and code within the same 10-minute budget: about 60–80 seconds for the UI and 30–40 seconds for code. These are not extra minutes after the slides. Aim for 9:30 overall and verify the actual duration by rehearsal.',
  'Use the source notes for discussion. Do not read the technical notes and URLs aloud.',
  `Prepared narration: approximately ${wordCount} words. Presenter names and genuine contributions remain for the team to complete.`, '',
  ...notes.flatMap((entry, index) => [`## Slide ${index + 1}: ${entry.title}`, '', entry.narration, '', '**Sources**', '', ...entry.citations.map(citation => `- ${citation}`), '', ...(entry.technical ? ['**Discussion notes outside timed narration**', '', entry.technical, ''] : [])]),
].join('\n');
await fs.writeFile(narrationPath, humanScript);
const summarySha = await exists(summaryPath) ? createHash('sha256').update(await fs.readFile(summaryPath)).digest('hex') : null;
const screenshotSha = hasScreenshot ? createHash('sha256').update(await fs.readFile(screenshot)).digest('hex') : null;
await fs.writeFile(path.join(buildDir, 'build_summary.json'), JSON.stringify({ root, created: new Date().toISOString(), draft: isDraft, audited, records: seen.size, summaryPath, summarySha, screenshot: hasScreenshot ? screenshot : null, screenshotSha, font, slides: 12, nativeTableSlides, nativeChartSlides: audited ? [8, 10] : [], narrationWords: wordCount, final: deliveredPath, validation: result, unitEvidenceAvailable: Object.keys(evidence).length }, null, 2));
console.log(JSON.stringify({ status: isDraft ? 'draft-created' : 'created', path: deliveredPath, humanScript: narrationPath, slides: 12, realTestRuns: seen.size, audited, renders: buildDir, narrationWords: wordCount }));
