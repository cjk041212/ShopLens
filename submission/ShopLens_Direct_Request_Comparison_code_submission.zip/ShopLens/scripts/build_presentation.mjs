/**
 * Rebuild the editable course presentation from real local artifacts.
 * Usage: <bundled node> scripts/build_presentation.mjs --root /path/to/NLP-Coursework
 * Optional: --output-dir /path/to/deliverables --ui-screenshot /path/to/real-ui.png
 * Runtime paths can be overridden with RUNTIME_NODE_MODULES, RUNTIME_PYTHON,
 * and SHOPLENS_PRESENTATION_SKILL. No model training or network access occurs.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const argv = process.argv.slice(2);
const option = (name, fallback) => {
  const at = argv.indexOf(name);
  return at >= 0 ? argv[at + 1] : fallback;
};
const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const workspaceDir = path.resolve(scriptDir, '..');
const dataRoot = path.resolve(option('--root', process.env.SHOPLENS_ROOT || workspaceDir));
const outputDir = path.resolve(option('--output-dir', path.join(workspaceDir, 'deliverables')));
const runtimeBase = process.env.SHOPLENS_RUNTIME_BASE || '';
const modules = process.env.RUNTIME_NODE_MODULES || path.join(runtimeBase, 'node/node_modules');
const python = process.env.RUNTIME_PYTHON || path.join(runtimeBase, 'python/bin/python3');
const skill = process.env.SHOPLENS_PRESENTATION_SKILL || '';
process.env.RUNTIME_NODE_MODULES = modules;
const runtimeRequire = createRequire(path.join(modules, '../package.json'));
const { Presentation, PresentationFile } = await import(pathToFileURL(runtimeRequire.resolve('@oai/artifact-tool')).href);
const { resolvePresentationFont, applyPresentationChartFont, finalizePresentation } = await import(pathToFileURL(path.join(skill, 'container_tools/artifact_tool_utils.mjs')).href);
const font = resolvePresentationFont();
const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
const buildDir = path.join(workspaceDir, '.presentation-build', timestamp);
const validatedDir = path.join(workspaceDir, '.presentation-validated', timestamp);
await fs.mkdir(buildDir, { recursive: true });
await fs.mkdir(validatedDir, { recursive: true });
await fs.mkdir(outputDir, { recursive: true });

const domains = ['baby', 'sports', 'clothing'];
const names = { baby: 'Baby', sports: 'Sports & Outdoors', clothing: 'Clothing & Accessories' };
const modes = ['popularity', 'mf', 'tfidf', 'text', 'multimodal', 'adapted'];
const labels = { popularity: 'Popularity', mf: 'BPR + history fold-in', tfidf: 'TF-IDF', text: 'MiniLM', multimodal: 'CLIP + MiniLM', adapted: 'CLIP + adapted MiniLM' };
const C = { ink: '#17243C', muted: '#64748B', blue: '#3868EC', green: '#118A7A', orange: '#E69A40', bg: '#FAFBFD', line: '#DCE3EE', white: '#FFFFFF', pale: '#EEF3FF' };
const sources = {
  data: 'https://mcauleylab.ucsd.edu/public_datasets/data/amazon/datasets.html',
  clip: 'https://proceedings.mlr.press/v139/radford21a.html',
  clipCode: 'https://github.com/openai/CLIP',
  minilm: 'https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2',
  bpr: 'https://arxiv.org/abs/1205.2618',
  course: 'https://ntulearn.ntu.edu.sg/ultra/courses/_2706623_1/file/_6190402_1?courseId=_2706623_1',
};
async function readJson(filename) {
  try { return JSON.parse(await fs.readFile(filename, 'utf8')); } catch { return {}; }
}
async function exists(filename) { try { return (await fs.stat(filename)).isFile(); } catch { return false; } }
const audits = {}, results = {}, features = {}, catalogs = {};
for (const domain of domains) {
  audits[domain] = await readJson(path.join(dataRoot, 'data/processed', domain, 'audit.json'));
  features[domain] = await readJson(path.join(dataRoot, 'artifacts', domain, 'features.json'));
  const document = await readJson(path.join(dataRoot, 'artifacts', domain, 'results.json'));
  results[domain] = (document.results || []).filter(row => row.split === 'test' && row.data_audit?.synthetic !== true && row.features_metadata?.synthetic !== true && !row.run_protocol?.evaluation_subset);
  const rows = results[domain];
  if (rows.length) {
    const reference = rows[0];
    for (const row of rows) {
      for (const key of ['items_sha256', 'events_sha256', 'n_users', 'n_targets']) {
        if (JSON.stringify(row[key]) !== JSON.stringify(reference[key])) throw new Error(`Incompatible result data: ${domain}/${key}`);
      }
      for (const key of ['candidate_set', 'history', 'averaging', 'n_catalog_items', 'positive_feedback', 'max_history']) {
        if (JSON.stringify(row.run_protocol?.[key]) !== JSON.stringify(reference.run_protocol?.[key])) throw new Error(`Incompatible result protocol: ${domain}/${key}`);
      }
    }
    for (const mode of modes) {
      const selected = rows.filter(row => row.model === mode);
      if (new Set(selected.map(row => row.seed)).size !== selected.length) throw new Error(`Duplicate result seeds: ${domain}/${mode}`);
      if (selected.some(row => row.selected_features_sha256 !== selected[0].selected_features_sha256)) throw new Error(`Incompatible features across seeds: ${domain}/${mode}`);
    }
  }
  try { catalogs[domain] = (await fs.readFile(path.join(dataRoot, 'data/processed', domain, 'items.jsonl'), 'utf8')).split('\n').filter(Boolean).map(line => JSON.parse(line)); } catch { catalogs[domain] = []; }
}
const nf = value => Number.isFinite(value) ? value.toLocaleString('en-US') : 'Pending';
const numeric = value => typeof value === 'number' && Number.isFinite(value);
const mean = values => values.reduce((a, b) => a + b, 0) / values.length;
const sd = values => values.length > 1 ? Math.sqrt(values.reduce((a, b) => a + (b - mean(values)) ** 2, 0) / (values.length - 1)) : 0;
function aggregate(domain, mode, metric = 'ndcg@10', subgroup = null) {
  const bySeed = new Map();
  for (const row of results[domain]) {
    if (row.model !== mode) continue;
    const value = subgroup ? row[subgroup]?.[metric] : row[metric];
    if (numeric(value)) bySeed.set(row.seed, value);
  }
  const values = [...bySeed.values()];
  return values.length ? { mean: mean(values), sd: sd(values), n: values.length } : null;
}
const formatScore = value => value ? (value.n > 1 ? `${value.mean.toFixed(4)}±${value.sd.toFixed(4)} (n=${value.n})` : `${value.mean.toFixed(4)} (n=1)`) : 'Pending';
const budgetPath = path.join(dataRoot, 'experiments/baseline_budget.json');
const budgetDocument = await readJson(budgetPath);
const budgetChecks = Array.isArray(budgetDocument.checks) ? budgetDocument.checks : [];
const budgetSeen = new Set();
for (const check of budgetChecks) {
  const row = check.result;
  const identity = `${check.domain}/${check.seed}`;
  if (!domains.includes(check.domain) || ![42, 43, 44].includes(check.seed) || check.epochs !== 20 ||
      row?.model !== 'mf' || row?.split !== 'test' || row.seed !== check.seed || budgetSeen.has(identity)) {
    throw new Error(`Invalid or duplicate independent MF budget check: ${identity}`);
  }
  budgetSeen.add(identity);
  if (row.data_audit?.synthetic || row.features_metadata?.synthetic || row.run_protocol?.evaluation_subset) {
    throw new Error(`Non-formal MF sensitivity result: ${identity}`);
  }
  const curve = check.validation_curve;
  if (!Array.isArray(curve) || curve.length !== 20 || !curve.every(numeric) ||
      check.selected_epoch !== curve.indexOf(Math.max(...curve)) + 1 || row.selected_epoch !== check.selected_epoch) {
    throw new Error(`MF sensitivity checkpoint does not match validation-only selection: ${identity}`);
  }
  const primary = results[check.domain].find(result => result.model === 'mf' && result.seed === check.seed);
  if (primary) {
    for (const key of ['items_sha256', 'events_sha256', 'n_users', 'n_targets']) {
      if (JSON.stringify(row[key]) !== JSON.stringify(primary[key])) throw new Error(`MF budget data mismatch: ${identity}/${key}`);
    }
    for (const key of ['candidate_set', 'history', 'averaging', 'n_catalog_items', 'positive_feedback', 'max_history']) {
      if (JSON.stringify(row.run_protocol?.[key]) !== JSON.stringify(primary.run_protocol?.[key])) throw new Error(`MF budget protocol mismatch: ${identity}/${key}`);
    }
  }
}
function pairedChanges(domain, candidate, baseline, subgroup = null) {
  const values = mode => new Map(results[domain].filter(row => row.model === mode).map(row =>
    [row.seed, subgroup ? row[subgroup]?.['ndcg@10'] : row['ndcg@10']]));
  const after = values(candidate), before = values(baseline);
  return [...after].filter(([seed, value]) => numeric(value) && numeric(before.get(seed)))
    .map(([seed, value]) => ({ domain, seed, delta: value - before.get(seed) }));
}
const adaptationChanges = domains.flatMap(domain => pairedChanges(domain, 'adapted', 'multimodal'));
const adaptationWins = adaptationChanges.filter(change => change.delta > 0).length;
const adaptationNarration = !adaptationChanges.length
  ? 'The paired adaptation comparison remains pending.'
  : adaptationWins > 0 && adaptationWins < adaptationChanges.length
    ? `Review adaptation shows mixed outcomes: NDCG at ten improves in ${adaptationWins} of ${adaptationChanges.length} completed domain-and-seed pairs. This does not establish a stable gain.`
    : adaptationWins === 0
      ? `Review adaptation improves none of the ${adaptationChanges.length} completed domain-and-seed pairs. The completed runs do not support a recommendation gain from this adaptation setting.`
      : `Review adaptation has positive differences in all ${adaptationChanges.length} completed domain-and-seed pairs under this budget. These observations alone do not establish stable gains beyond the measured setting.`;
function sensitivityNotes() {
  const lines = ['The main table uses a fixed five-epoch primary budget for trainable recommenders. Its MF row is not an extensively tuned baseline. The independent twenty-epoch MF check examines the limited budget after the five-epoch validation curves continued to rise. The check keeps the primary table intact and selects each checkpoint using validation NDCG only.'];
  if (!budgetChecks.length) lines.push('The independent twenty-epoch sensitivity artifact is pending. No twenty-epoch performance number is available in this snapshot.');
  for (const domain of domains) {
    const checks = budgetChecks.filter(check => check.domain === domain && numeric(check.result['ndcg@10']));
    if (checks.length) {
      const values = checks.map(check => check.result['ndcg@10']);
      const score = { mean: mean(values), sd: sd(values), n: values.length };
      const primary = aggregate(domain, 'mf');
      const matched = checks.map(check => {
        const row = results[domain].find(result => result.model === 'mf' && result.seed === check.seed);
        return numeric(row?.['ndcg@10']) ? check.result['ndcg@10'] - row['ndcg@10'] : null;
      }).filter(numeric);
      lines.push(`${names[domain]} independent MF twenty-epoch NDCG@10: ${formatScore(score)}. Primary five-epoch MF: ${formatScore(primary)}. ${matched.length ? `Mean difference over ${matched.length} paired seeds: ${mean(matched).toFixed(6)}.` : 'The paired primary comparison remains pending.'} Validation-selected epochs: ${checks.map(check => `${check.seed}: ${check.selected_epoch}`).join(', ')}.`);
    }
    const changes = pairedChanges(domain, 'adapted', 'multimodal');
    if (changes.length) lines.push(`${names[domain]} adaptation improves NDCG@10 in ${changes.filter(change => change.delta > 0).length}/${changes.length} paired seeds. Mean paired change: ${mean(changes.map(change => change.delta)).toFixed(6)}. Individual differences: ${changes.map(change => `${change.seed}: ${change.delta.toFixed(6)}`).join(', ')}.`);
    const sparse = ['tfidf', 'text', 'multimodal', 'adapted'].map(mode => {
      const value = aggregate(domain, mode, 'ndcg@10', 'low_interaction');
      return value ? `${labels[mode]} ${value.mean.toPrecision(4)} (n=${value.n})` : null;
    }).filter(Boolean);
    if (sparse.length) lines.push(`${names[domain]} low-interaction mean NDCG@10: ${sparse.join(', ')}. The group contains products with at most five distinct training-positive users, including zero-interaction products. It does not isolate strictly unseen-item cold start.`);
  }
  lines.push('The twenty-epoch check is a sensitivity analysis, not a second main table or evidence that MF has reached its optimal hyperparameters. Differences remain descriptive without a statistical significance test. Adaptation repeats vary the downstream recommendation seed while holding the adapted encoder fixed.');
  return lines.join('\n\n');
}
const totalRuns = domains.reduce((total, domain) => total + results[domain].length, 0);
const hasResults = totalRuns > 0;
const hasChartData = domains.some(domain => modes.some(mode => aggregate(domain, mode)));
const syntheticScope = domains.some(domain => audits[domain].synthetic === true || features[domain].synthetic === true);
if (syntheticScope) throw new Error('The presentation builder accepts real course artifacts only. Synthetic UI fixtures are excluded.');

const p = Presentation.create({ slideSize: { width: 1280, height: 720 } });
const notes = [];
let sequence = 0;
function text(slide, value, x, y, width, height, size = 27, color = C.ink, bold = false, extra = {}) {
  const shape = slide.shapes.add({ geometry: 'textbox', name: `text-${++sequence}`, position: { left: x, top: y, width, height }, fill: 'none', line: { fill: 'none', width: 0 } });
  shape.text = value;
  shape.text.style = { typeface: font, fontSize: size, color, bold, verticalAlignment: 'top', wrap: 'square', autoFit: 'none', insets: 0, ...extra };
  return shape;
}
function slide(title, subtitle = null) {
  const s = p.slides.add();
  s.background.fill = C.bg;
  text(s, title, 72, 57, 1136, 75, 43, C.ink, true);
  if (subtitle) text(s, subtitle, 74, 137, 1130, 56, 24, C.muted);
  text(s, `${String(p.slides.items.length).padStart(2, '0')}  ShopLens`, 1070, 670, 140, 25, 17, C.muted, false, { alignment: 'right' });
  return s;
}
function note(s, title, narration, citations = [], technicalNotes = '') {
  s.speakerNotes.text = `${narration}${technicalNotes ? `\n\nAdditional discussion notes\n${technicalNotes}` : ''}\n\nSources\n${citations.join('\n')}`;
  notes.push({ title, narration, citations, technicalNotes });
}
function table(s, values, y, height, widths, fontSize = 25) {
  const tab = s.tables.add({ rows: values.length, columns: values[0].length, left: 72, top: y, width: 1136, height, values, columnWidths: widths });
  tab.styleOptions = { headerRow: true, bandedRows: false };
  tab.borders.assign({ style: 'solid', fill: C.line, width: 1 });
  tab.cells.block({ row: 0, column: 0, rowCount: values.length, columnCount: values[0].length }).assign({ textStyle: { typeface: font, fontSize, color: C.ink }, fill: C.white, margins: { left: 15, right: 12, top: 10, bottom: 8 } });
  tab.cells.block({ row: 0, column: 0, rowCount: 1, columnCount: values[0].length }).assign({ fill: C.ink, textStyle: { typeface: font, fontSize, color: C.white, bold: true } });
  return tab;
}
function node(s, value, x, y, w, h, color = C.ink, fill = C.white, size = 25) {
  const shape = s.shapes.add({ geometry: 'rect', name: `diagram-${++sequence}`, position: { left: x, top: y, width: w, height: h }, fill, line: { fill: color, width: 1.8 } });
  shape.text = value;
  shape.text.style = { typeface: font, fontSize: size, color, alignment: 'center', verticalAlignment: 'middle', insets: 10, autoFit: 'none', wrap: 'square' };
  return shape;
}
function connect(s, a, b, fromSide = 'right', toSide = 'left') {
  return s.shapes.connect(a, b, { kind: 'elbow', fromSide, toSide, line: { fill: C.muted, width: 2 }, tail: { type: 'triangle', width: 'med', length: 'med' } });
}
const usedImages = new Set();
async function image(s, domain, x, y, w, h, preferred = null) {
  const candidates = catalogs[domain].filter(row => !usedImages.has(row.item_id));
  if (preferred) candidates.sort((a, b) => Number(preferred.test(String(b.title))) - Number(preferred.test(String(a.title))));
  for (const item of candidates) {
    if (!item.image_path) continue;
    const filename = path.resolve(dataRoot, item.image_path);
    if (!filename.startsWith(dataRoot + path.sep) || !(await exists(filename))) continue;
    const bytes = await fs.readFile(filename);
    s.images.add({ blob: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), contentType: filename.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg', alt: item.title || item.item_id, fit: 'contain', position: { left: x, top: y, width: w, height: h } });
    usedImages.add(item.item_id);
    return item;
  }
  return null;
}

// 1. Minimal cover, with a real product photograph and editable title.
{
  const s = p.slides.add(); s.background.fill = C.bg;
  text(s, 'ShopLens', 72, 118, 680, 100, 78, C.ink, true);
  text(s, 'Multimodal product recommendation\nwith CLIP and review-adapted MiniLM', 76, 245, 700, 175, 39, C.ink);
  text(s, 'EE6405  Natural Language Processing\nGroup coursework', 77, 521, 650, 80, 26, C.muted);
  let chosen = await image(s, 'clothing', 850, 150, 340, 340, /shoe|jacket|dress/i);
  if (!chosen) chosen = await image(s, 'sports', 850, 150, 340, 340, /backpack|shoe|ball/i);
  if (!chosen) chosen = await image(s, 'baby', 850, 150, 340, 340, /toy|bottle|teether/i);
  if (chosen) text(s, `Catalog example  ${chosen.item_id}`, 835, 515, 360, 40, 19, C.muted, false, { alignment: 'center' });
  note(s, 'ShopLens', 'Hello. Our project is ShopLens, a local product recommendation system that combines product photographs with language representations. We study whether visual information adds value beyond product text, and whether adapting a small text encoder with customer reviews improves recommendation. The interface lets a user select a few products and inspect how the resulting ranking changes across models. We evaluate the models separately on three Amazon product domains.', [sources.data, sources.clip, sources.minilm]);
}
// 2. Concrete questions, no unsupported performance claims.
{
  const s = slide('Research questions');
  text(s, '01', 76, 211, 80, 60, 43, C.blue, true);
  text(s, 'Do product images improve ranking\nbeyond language features?', 180, 211, 1000, 120, 39, C.ink, true);
  text(s, '02', 76, 392, 80, 60, 43, C.green, true);
  text(s, 'Does review adaptation help products\nwith fewer observed interactions?', 180, 392, 1000, 120, 39, C.ink, true);
  text(s, 'NLP focus: textual representations, contrastive adaptation and controlled comparisons', 76, 600, 1120, 47, 24, C.muted);
  note(s, 'Research questions', 'The first question examines adding image features. We compare MiniLM text against a ranker with the same history module and latent size, plus a CLIP image branch. That branch adds trainable parameters, so this is not a capacity-matched comparison. The second question concerns language adaptation. A review describes a product in a customer’s own words, which may differ from its catalogue description. We adapt MiniLM to bring a review closer to the corresponding product text, and then test whether that representation helps recommendation. Neither question assumes that the more complex model must perform better.', [sources.clip, sources.minilm, path.join(dataRoot, 'src/shoplens/models.py'), path.join(dataRoot, 'src/shoplens/adapt.py')]);
}
// 3. Editable dataset table populated from current audit files.
{
  const s = slide('Three Amazon product domains', 'Counts describe the current cleaned catalogue and interaction files');
  const values = [['Domain', 'Products', 'Users', 'Events', 'Test positives']];
  for (const domain of domains) {
    const count = audits[domain].counts || {};
    values.push([names[domain], nf(count.items), nf(count.users), nf(count.events), nf(count.positives?.test)]);
  }
  table(s, values, 220, 290, [360, 185, 185, 205, 201], 24);
  text(s, 'The domains share one data source. Image decoding and text availability determine the final sample.', 76, 548, 1125, 75, 26, C.muted);
  note(s, 'Datasets', 'We use the Baby, Sports and Outdoors, and Clothing, Shoes and Jewelry domains from Amazon Reviews 2014. Each domain contains ratings and timestamps, while metadata links the products to descriptions and photographs. The table reads directly from the current data audit. It may show fewer records than the original five-core release because we require usable text and real, decodable images. The three domains provide separate benchmarks, although they come from the same source. The course instructor should confirm that this meets the requested dataset count.', [sources.data, ...domains.map(domain => path.join(dataRoot, 'data/processed', domain, 'audit.json'))]);
}
// 4. Native editable split diagram.
{
  const s = slide('Chronological evaluation protocol', 'Global timestamp quantiles define the split separately in each domain');
  const train = node(s, 'Training\n80% time quantile', 75, 230, 595, 135, C.blue, C.pale, 31);
  const valid = node(s, 'Validation\nNext 10%', 715, 230, 230, 135, C.green, C.white, 29);
  const test = node(s, 'Test\nFinal 10%', 990, 230, 215, 135, C.ink, C.white, 29);
  connect(s, train, valid); connect(s, valid, test);
  text(s, 'History uses strictly earlier positive events, with rating ≥ 4', 76, 422, 1120, 47, 29, C.ink, true);
  text(s, 'Full catalogue ranking excludes products already liked. Model weights remain fixed during test evaluation.', 76, 488, 1110, 90, 28, C.muted);
  text(s, 'Timestamp ties can make the record proportions differ from 80 / 10 / 10.', 76, 610, 1120, 35, 23, C.muted);
  note(s, 'Evaluation protocol', 'We split each domain using global timestamp quantiles rather than randomly mixing future and past interactions. Four- and five-star ratings count as positive feedback. For every target, the history contains only strictly earlier positive events and at most twenty recent distinct products. We rank the full prepared catalogue, excluding all previously liked products. Repeat targets are skipped. Test evaluation is prequential: earlier test interactions can become history for later targets, but the model weights never change. Equal timestamps do not enter a target’s history. We average each user’s target scores first, then average across users.', [path.join(dataRoot, 'src/shoplens/models.py'), path.join(dataRoot, 'src/shoplens/evaluate.py')]);
}
// 5. Native editable encoder table.
{
  const s = slide('Image and language representations');
  table(s, [
    ['Component', 'Representation', 'Training scope'],
    ['CLIP ViT-B/32', '512-dimensional image vector', 'Frozen image encoder'],
    ['MiniLM-L6-v2', '384-dimensional text vector', 'Frozen baseline'],
    ['Adapted MiniLM', 'Review-aligned text vector', 'Final two Transformer blocks'],
  ], 185, 330, [315, 438, 383], 25);
  text(s, 'Catalogue text contains title + description. Long descriptions use 224-wordpiece chunks and normalized aggregation.', 76, 550, 1125, 80, 27, C.muted);
  note(s, 'Representations', 'The image encoder is CLIP ViT-B/32. We freeze it and extract one vector from each real product photograph. MiniLM-L6-v2 provides a separate compact text representation. This separation makes the language work explicit and avoids relying on CLIP’s short text input for long descriptions. Catalogue encoding splits long text into chunks of two hundred and twenty-four wordpieces and aggregates their normalized vectors. Catalogue text contains only the title and description. Reviews enter the separate language-adaptation task, and only training-period reviews can enter that task.', [sources.clip, sources.clipCode, sources.minilm, path.join(dataRoot, 'src/shoplens/features.py')]);
}
// 6. Explicitly requested editable architecture diagram.
{
  const s = slide('History-conditioned recommendation model');
  const im = node(s, 'CLIP image\n512 dimensions', 75, 188, 270, 100, C.blue, C.pale, 27);
  const tx = node(s, 'MiniLM text\n384 dimensions', 75, 340, 270, 100, C.green, C.white, 27);
  const fusion = node(s, 'Projection + fusion\n128 dimensions', 430, 265, 320, 115, C.ink, C.white, 29);
  const history = node(s, 'Recent history\nMean pooling + MLP', 850, 175, 350, 110, C.ink, C.white, 28);
  const scoring = node(s, 'User–item dot product\nFull catalogue ranking', 850, 390, 350, 110, C.blue, C.pale, 27);
  connect(s, im, fusion); connect(s, tx, fusion); connect(s, fusion, history); connect(s, history, scoring, 'bottom', 'top');
  connect(s, fusion, scoring);
  text(s, 'The same history encoder supports existing users and a new local session.', 76, 570, 1120, 60, 29, C.ink, true);
  note(s, 'Architecture', 'The recommendation network projects image and text features, combines them through a small fusion network, and normalizes the resulting product vector. The latent dimension is one hundred and twenty-eight. A user representation comes from mean pooling recent liked-product vectors followed by an MLP. The final score is a user–item dot product. Because this model conditions on product history instead of requiring a learned user ID, a new user can select products in the interface and immediately receive recommendations through the same scoring code. The text-only ablation removes the image input while keeping the remaining architecture comparable.', [path.join(dataRoot, 'src/shoplens/models.py'), path.join(dataRoot, 'src/shoplens/inference.py')]);
}
// 7. Editable formulas and concise training description.
{
  const s = slide('Two training objectives');
  text(s, 'Recommendation', 75, 188, 520, 55, 33, C.blue, true);
  text(s, 'BPR pairwise ranking', 75, 256, 520, 55, 31, C.ink, true);
  text(s, 'L = −log σ(5 × (s_positive − s_negative))', 75, 325, 1125, 60, 32, C.ink);
  text(s, 'Observed positives outrank sampled unobserved products.\nTraining positives never serve as sampled negatives.', 75, 407, 1120, 100, 28, C.muted);
  text(s, 'Language adaptation', 75, 535, 425, 45, 31, C.green, true);
  text(s, 'Symmetric contrastive review–description loss\nTraining-period reviews only, with item-disjoint adaptation validation', 500, 531, 695, 100, 27, C.ink);
  note(s, 'Training objectives', 'Recommendation training uses a scaled BPR loss. A positive interaction should receive a higher score than a sampled unobserved item. We exclude the user’s observed training positives from the negative pool. Unobserved items are a training contrast, not verified dislikes. Validation NDCG selects the recommendation checkpoint without consulting test labels. For language adaptation, we fine-tune the last two MiniLM blocks using a symmetric contrastive loss between reviews and their corresponding product descriptions. Each batch keeps at most one pair per product to reduce obvious false negatives. Adaptation validation uses held-out products drawn only from training-period review pairs.', [sources.bpr, path.join(dataRoot, 'src/shoplens/train.py'), path.join(dataRoot, 'src/shoplens/adapt.py')]);
}
// 8. Editable ablation table.
{
  const s = slide('Six controlled comparisons');
  table(s, [
    ['Method', 'Information', 'Purpose'],
    ['Popularity', 'Training interaction counts', 'Simple reference'],
    ['BPR + history fold-in', 'Learned item factors + history', 'Behavioural baseline'],
    ['TF-IDF', 'Product text + history', 'Traditional NLP baseline'],
    ['MiniLM', 'Semantic text + history', 'Neural language baseline'],
    ['CLIP + MiniLM', 'Image + text + history', 'Contribution of images'],
    ['CLIP + adapted MiniLM', 'Same inputs, adapted text', 'Contribution of adaptation'],
  ], 168, 420, [350, 405, 381], 24);
  text(s, 'Identical data and candidates. Recommender seeds: 42, 43, 44. Encoder adaptation seed: 42.', 76, 613, 1120, 35, 23, C.muted);
  note(s, 'Controlled comparisons', 'We compare six methods under a fixed five-epoch primary training budget. Popularity and TF-IDF require no iterative training. The behavioural baseline learns product factors through BPR, then generates a user vector from history using a fixed ridge fold-in solution. This differs from standard user-ID matrix-factorization evaluation. MiniLM introduces semantic text features, CLIP adds images, and the final model changes the text representation through review adaptation. All methods share the cleaned catalogue and temporal protocol. Three seeds repeat downstream recommendation training with the adapted encoder fixed. A separate twenty-epoch MF sensitivity check examines the short primary budget and selects checkpoints through validation only.', [sources.bpr, path.join(dataRoot, 'src/shoplens/train.py'), path.join(dataRoot, 'src/shoplens/inference.py'), budgetPath]);
}
// 9. Editable chart only when real scores exist.
{
  const s = slide('Test ranking quality', 'Fixed 5-epoch primary budget. User-macro NDCG@10 across available seeds.');
  if (hasChartData) {
    const palette = ['#9AA8BA', '#606F87', '#DCA44C', '#118A7A', '#3868EC', '#8B63BD'];
    const chart = s.charts.add('bar', {
      position: { left: 74, top: 205, width: 1130, height: 405 },
      categories: domains.map(domain => names[domain]),
      series: modes.map((mode, index) => ({ name: labels[mode], values: domains.map(domain => {
        const value = aggregate(domain, mode)?.mean;
        return value == null ? null : Number(value.toFixed(8));
      }), fill: palette[index] })),
      hasLegend: true, legend: { position: 'bottom', textStyle: { fontSize: 22 } },
      barOptions: { direction: 'column', grouping: 'clustered', gapWidth: 70 },
      xAxis: { textStyle: { fontSize: 25, fill: C.ink }, majorGridlines: null },
      yAxis: { min: 0, numberFormatCode: '0.000', textStyle: { fontSize: 22, fill: C.muted }, majorGridlines: { fill: C.line, width: 1 } },
      chartFill: 'none', plotAreaFill: 'none',
    });
    applyPresentationChartFont(chart, { fontFamily: font });
    text(s, 'The following slide reports sample standard deviations and seed counts.', 76, 622, 1110, 35, 23, C.muted);
  } else {
    text(s, 'Test results pending', 78, 253, 1100, 90, 54, C.blue, true);
    text(s, 'The project has not produced verified real-data ranking scores at this snapshot.\nThe builder will populate this chart after evaluation writes results.json.', 78, 370, 1110, 130, 30, C.muted);
  }
  note(s, 'Ranking quality', hasChartData ? `This chart reads the test scores directly from the saved result files under the fixed five-epoch primary budget. It shows user-macro NDCG at ten for each domain. Missing bars indicate pending results. MiniLM against CLIP plus MiniLM addresses the image question. The two multimodal variants address adaptation. ${adaptationNarration} The next slide reports variation and the separate baseline-budget check. These measurements do not establish online business impact.` : 'At this snapshot, verified test results are still pending. We therefore show no performance bars and make no claim that adding images or adapting language improves recommendation. Once evaluation finishes, this presentation builder reads the local results files and populates the editable chart. The implementation and evaluation protocol can already be inspected, while the final experimental conclusion depends on those completed runs.', domains.map(domain => path.join(dataRoot, 'artifacts', domain, 'results.json')));
}
// 10. UI screenshot when available, otherwise an accurate local-demo sequence.
{
  const s = slide('Local interactive demonstration');
  const screenshot = option('--ui-screenshot', path.join(outputDir, 'assets/ui_screenshot.png'));
  if (await exists(screenshot)) {
    const bytes = await fs.readFile(screenshot);
    s.images.add({ blob: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), contentType: 'image/png', alt: 'Actual local ShopLens interface', fit: 'contain', position: { left: 72, top: 165, width: 560, height: 435 } });
    text(s, '01  Select 3–5 liked products', 675, 205, 520, 72, 30, C.ink, true);
    text(s, '02  Compare rankings on the\n      same preference history', 675, 320, 520, 105, 29, C.ink);
    text(s, '03  Inspect text evidence\n      and measured results', 675, 460, 520, 105, 29, C.ink);
  } else {
    text(s, 'Select 3–5 liked products', 77, 202, 1120, 55, 34, C.ink, true);
    text(s, 'Compare text and multimodal rankings on the same history', 77, 291, 1120, 75, 32, C.ink);
    text(s, 'Inspect product descriptions and actual feature similarities', 77, 397, 1120, 75, 32, C.ink);
    text(s, 'Open the experiment dashboard for all recorded runs', 77, 503, 1120, 75, 32, C.ink);
  }
  text(s, 'M4 deployment uses cached features and a small ranking network. The demo records no new training.', 76, 620, 1120, 38, 23, C.muted);
  note(s, 'Local demonstration', 'For the demonstration, choose a product domain and select three to five liked products. The interface recalculates recommendations from the trained model, excluding the selected products. In the model-comparison view, keep the same input history and inspect the top-ranked products. The table reports actual rank changes within the displayed top-K lists. In the evidence view, inspect the original descriptions and similarities to the selected history. Those similarities help us diagnose results, but they are not causal explanations of the neural network. Finally, the experiment view shows saved metrics and the original audit records. The local application uses cached features and small models without keeping the large encoders loaded.', [path.join(dataRoot, 'src/shoplens/ui.py'), path.join(dataRoot, 'src/shoplens/inference.py')]);
}
// 11. Real numeric summary with explicit pending cells.
{
  const s = slide('Observed outcomes and limits', 'Fixed 5-epoch primary budget. Checkpoints use validation only.');
  const values = [['Method', 'Baby', 'Sports', 'Clothing']];
  for (const mode of modes) values.push([labels[mode], ...domains.map(domain => formatScore(aggregate(domain, mode)))]);
  table(s, values, 200, 330, [350, 262, 262, 262], 23);
  text(s, 'NDCG@10: mean ± sample standard deviation for n ≥ 2. A single seed shows only its measured value. More metrics appear in the dashboard.', 76, 552, 1120, 65, 23, C.muted);
  const budgetSummary = domains.map(domain => {
    const checks = budgetChecks.filter(check => check.domain === domain);
    return `${domain === 'baby' ? 'Baby' : domain === 'sports' ? 'Sports' : 'Clothing'} ${checks.length ? mean(checks.map(check => check.result['ndcg@10'])).toFixed(4) : 'pending'}`;
  }).join(' · ');
  text(s, `Separate MF20 NDCG@10: ${budgetSummary} (${budgetChecks.length}/9 runs)`, 76, 625, 1120, 30, 23, C.muted);
  const observed = domains.map(domain => {
    const candidates = modes.map(mode => ({ mode, value: aggregate(domain, mode) })).filter(record => record.value).sort((a, b) => b.value.mean - a.value.mean);
    return candidates.length ? `${names[domain]} currently has the highest mean NDCG at ten for ${labels[candidates[0].mode]}, ${candidates[0].value.mean.toFixed(4)}, across ${candidates[0].value.n} saved seed results.` : `${names[domain]} has no completed test score at this snapshot.`;
  }).join(' ');
  note(s, 'Outcomes and limits', `${observed} Multiple seeds provide a mean and sample standard deviation. A single seed shows only its measured score. The primary MF result has the same five-epoch budget as the neural recommenders and cannot represent a fully tuned baseline. An independent twenty-epoch check uses validation-only checkpoint selection. Detailed sensitivity results and sparse-item outcomes appear in these speaker notes. The domains share one Amazon source and static catalogue snapshots. Offline ranking predicts recorded positive feedback, without establishing purchase conversion or causal explanations.`, [...domains.map(domain => path.join(dataRoot, 'artifacts', domain, 'results.json')), budgetPath, sources.data], sensitivityNotes());
}
// 12. Primary references with editable, readable citations.
{
  const s = slide('References and reproducibility');
  text(s, '[1] Amazon Reviews 2014\nUCSD public product data archive', 77, 172, 1110, 76, 27, C.ink);
  text(s, '[2] Radford et al., 2021\nLearning Transferable Visual Models From Natural Language Supervision', 77, 272, 1110, 78, 27, C.ink);
  text(s, '[3] Sentence Transformers\nall-MiniLM-L6-v2 model card', 77, 373, 1110, 75, 27, C.ink);
  text(s, '[4] Rendle et al., UAI 2009\nBPR: Bayesian Personalized Ranking from Implicit Feedback', 77, 474, 1110, 78, 27, C.ink);
  text(s, 'Source URLs and artifact paths appear in speaker notes.\nCode, data audits and saved run records accompany this presentation.', 77, 592, 1110, 62, 23, C.muted);
  note(s, 'References', 'Our references are the official Amazon data archive, the CLIP paper and implementation, the MiniLM model card, and the original BPR paper. The complete project includes data and feature checksums, training settings and saved evaluation records so the comparison can be reproduced. We keep the group contribution and AI disclosure documents separate for the team to review and complete accurately. The presentation requires human narration, and this package does not generate an artificial voice. Thank you.', Object.values(sources));
}

if (p.slides.items.length !== 12) throw new Error('Expected exactly 12 slides');
for (const [index, s] of p.slides.items.entries()) {
  const png = await p.export({ slide: s, format: 'png', scale: 1 });
  await fs.writeFile(path.join(buildDir, `slide-${String(index + 1).padStart(2, '0')}.png`), new Uint8Array(await png.arrayBuffer()));
}
const candidatePath = path.join(buildDir, 'candidate.pptx');
await (await PresentationFile.exportPptx(p)).save(candidatePath);
const finalPath = path.join(validatedDir, 'ShopLens_presentation.pptx');
const result = await finalizePresentation({
  workspaceDir, candidatePath, finalPath, pythonExecutable: python,
  integrityValidatorPath: path.join(skill, 'container_tools/inspect_presentation_package_integrity.py'),
  layoutValidatorPath: path.join(skill, 'container_tools/inspect_presentation_layout_geometry.py'),
  layoutArgs: ['--expected-slide-size-emu', '12192000,6858000', '--validate-bullet-geometry', '--validate-heading-fit',
    ...[3, 5, 8, 11].flatMap(number => ['--require-native-table-slide', String(number)])],
  explicitTotalSlideCount: 12,
  requiredNativeTableOwnerSlides: [3, 5, 8, 11],
  requiredNativeChartOwnerSlides: hasChartData ? [9] : [],
  materializeLiteralChartWorkbooks: hasChartData,
  fontPolicy: { basis: 'design', families: [font] },
  verifyArtifactToolImport: true,
  receiptPath: path.join(buildDir, 'validation.json'),
});
await fs.copyFile(finalPath, path.join(outputDir, 'ShopLens_presentation.pptx'));
const script = [
  '# ShopLens human narration script',
  '',
  'Record with a real group member’s voice. Presenter names and final contributions must be completed by the team.',
  'Target duration: approximately 8–9 minutes including a short local demonstration. Rehearse once and keep the final recording below 10 minutes.',
  '',
  ...notes.flatMap((entry, index) => [`## Slide ${index + 1}: ${entry.title}`, '', entry.narration, '', '**Sources**', '', ...entry.citations.map(source => `- ${source}`), '',
    ...(entry.technicalNotes ? ['**Additional discussion notes (not part of the timed narration)**', '', entry.technicalNotes, ''] : [])]),
].join('\n');
await fs.writeFile(path.join(outputDir, 'ShopLens_human_narration.md'), script);
await fs.writeFile(path.join(buildDir, 'build_summary.json'), JSON.stringify({ dataRoot, timestamp, font, realTestRuns: totalRuns, primaryEpochBudget: 5, independentMFBudgetChecks: budgetChecks.length, slideCount: 12, pendingResults: !hasResults, final: path.join(outputDir, 'ShopLens_presentation.pptx'), validation: result }, null, 2));
console.log(JSON.stringify({ status: 'created', path: path.join(outputDir, 'ShopLens_presentation.pptx'), slides: 12, realTestRuns: totalRuns, renders: buildDir, humanScript: path.join(outputDir, 'ShopLens_human_narration.md') }));
