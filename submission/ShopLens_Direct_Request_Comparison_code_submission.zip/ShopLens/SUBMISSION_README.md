# Independent baseline + Qwen submission package

This is a code, report, and result-evidence package. Raw reviews, raw product photo files,
processed interaction/catalog files, model weights, feature matrices, virtual
environments, cache files, account configuration, logs, and original course
materials are deliberately absent. The UI initially shows its documented empty
state; reconstruct data and train artifacts before a model demo.
Small UI screenshots and illustrations inside the presentations are retained as
presentation evidence; the source photo dataset is not included.

Run the Python setup/tests and data commands in README.md, then run
`scripts/run_experiments.py` for the retained legacy comparison. Then follow
README_QWEN.md and install requirements-qwen.txt for the independent Qwen upgrade.
Use an allocated GPU and the declared domain/seed/objective configuration. The public-data download needs network access. Original files
are identified by SHA256 in the audit and source sidecars. Image availability
may change; validate the resulting catalog hashes before claiming exact replay.
The macOS lock file records the local environment; it is not a CUDA lock file.
The final package requires54 baseline records,9 baseline budget checks,27 Qwen
records, the full local-cache Qwen verification, and baseline preservation proof.
These checks concern experimental evidence; they do not replace human course forms.

Source code is preserved except for explicitly listed archive-only privacy and
portability transformations. Audit/result absolute private paths become project
relative paths. Their original source hashes and packaged hashes are both in
SUBMISSION_MANIFEST.json; hashes inside scientific records still identify the
original experiment inputs, not the redacted archive view.

The optional Node presentation generator requires externally supplied
`@oai/artifact-tool` and presentation helper runtime, outside Python requirements.
Set RUNTIME_NODE_MODULES, RUNTIME_PYTHON and SHOPLENS_PRESENTATION_SKILL explicitly.
Editable PPTX output is included when present; rebuilding it is optional for the
Python recommendation project. Scheduler project identifiers are removed from
PBS templates; choose your own allocated environment and scheduler project.

The final course submission also requires a real-voice video (maximum 10 minutes),
the group's actual contribution reflection with signatures, and the approved AI
disclosure form/records. Narration notes and unsigned drafts are preparation
materials, not completed video or signed forms. The team must also complete the
course peer evaluation separately. No upload or school submission is performed.
