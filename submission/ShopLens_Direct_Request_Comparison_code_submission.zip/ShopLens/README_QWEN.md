# ShopLens · Learning what shoppers mean

A text-led, image-assisted recommendation experiment for EE6405. The upgrade asks a specific question: **does adapting a language encoder to semantic matching also improve recommendation, or should we train it directly for preference ranking?**

The interactive demo presents the same shopping request to three model checkpoints. Users can inspect real product photos and ranking changes without first selecting a liked product. Optional product feedback also exercises the trained history recommenders. Research lab retains the formal history-based comparisons, measured ranking metrics and recorded training curves.

The default **Shopping Studio** workspace supports natural-language requests, optional reference images, editable constraints, feedback, comparison, final selection, and JSON/CSV/standalone HTML exports. **Find products** directly compares **Frozen Qwen**, **Semantic alignment LoRA** and **User preference LoRA** without requiring **More like this**. Each seed-42 model encodes the request and matches it to its own selected 1024-dimensional product-text vectors; CLIP image input and user constraints remain the same. Optional positive feedback adds that checkpoint's trained history recommender. **Compare models** shows observed result and rank changes. Direct request retrieval is an exploratory extension, separate from the formal history-based test metrics; changes are not evidence of improved recommendation quality. Select **Research lab** to open the original six pages. See `deliverables/ShopLens_Studio_guide.md` for preparation and a complete walkthrough.

## Explore the visual demo

All interface labels, controls, chart annotations and diagnostic messages are in English.

The interface has six pages: preferences, a product atlas, model comparison, a preference lab, recommendation evidence, and the experiment dashboard.

- **Product atlas:** open a fixed Frozen-reference PCA map, switch the model whose Top-K is highlighted, select a product and inspect its real photo. A deterministic catalog sample keeps the view readable; every selected product and current Top-K is included. Ranking still uses the full catalog. The reference coordinates and axis ranges stay fixed across model changes; 2D distances are not model scores or a comparison of independently trained embedding coordinates.
- **Model comparison:** inspect observed Top-K rank paths and a Jaccard overlap heatmap. Missing Top-K positions remain unknown rather than being assigned an invented rank.
- **Preference lab:** inspect full-dimensional history-to-candidate cosine heatmaps or a signed relationship network. An explicit removal experiment re-runs the actual exported user network after removing each active history product. It fixes the current capped history, does not backfill older items, and keeps all originally selected products excluded from candidates. Removing the only active item is unavailable, rather than a fabricated zero-change result.
- **Experiment dashboard:** inspect each actual training seed, its mean, and paired metric changes against Frozen. These views read the existing formal test records; the interactive map and removal checks do not create additional formal test results.

All interactive views use selected seed42 exports. Similarity edges and input-removal changes are descriptive diagnostics, not attention, modality weights or causal attributions. No language model is loaded by these local views, and expensive map/projection or removal work is cached or explicitly triggered.

## The controlled comparison

| Group | Candidate text encoder | LoRA supervision | Recommendation head |
| --- | --- | --- | --- |
| Frozen reference | Qwen3-Embedding-0.6B, frozen | None | BPR |
| Semantic alignment | Same Qwen + LoRA | Review-to-product multi-positive InfoNCE | BPR with detached candidate embeddings |
| Preference ranking | Same Qwen + LoRA | Positive-vs-negative BPR | Same BPR, joint gradients |

All groups share the selected warmup head, training cases and per-epoch negative samples for a given domain and seed. The image features are the existing frozen CLIP ViT-B/32 features. History text inputs always come from the base Qwen encoder; candidate text inputs depend on the group. This asymmetric design keeps serving consistent with training. The small history/candidate projection layers and user network remain trainable parts of the recommendation head.

The original six baselines, their results and original course deliverables remain in their original locations. Qwen artifacts and reports use independent names. Comparisons with earlier baselines are descriptive: their training budgets and architectures differ.

## Data and protocol

Three Amazon 2014 domains—Baby, Sports & Outdoors, and Clothing, Shoes & Jewelry—provide product descriptions, small auxiliary product images, and chronological interactions. They are three domains from one source; teacher acceptance as three datasets still needs confirmation.

For each domain and each seed (42, 43, 44):

1. Warm up a 128-dimensional asymmetric recommendation head on all eligible training histories. Select by full-catalog validation NDCG@10, with at most 20 epochs and early stopping (patience 3, minimum 5 epochs).
2. Share up to 30,000 eligible TRAIN examples with a matching positive review across all three groups. Each uses strictly earlier positive history, at most 20 distinct recent products. The target review is semantic training supervision, never a preference-history input.
3. Train each group for two adaptation epochs. Select epoch 1 or epoch 2 by the same downstream full-catalog validation NDCG@10.
4. Persist one formal full-catalog test result for the selected checkpoint, excluding all strictly earlier positive items. Report Recall/NDCG@10/@20 as within-user target means followed by a macro-average over users, including the cohort with at most 5 distinct positive training users per item.

Earlier validation/test interactions can enter later histories in the prequential protocol; weights remain fixed. Static catalog metadata has no historical availability timestamps. The low-interaction cohort is not a strict cold-start claim.

Text encoding uses the pinned model revision `97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3`, max length 256, left padding, last-valid-token pooling, and L2 normalization. LoRA uses rank 8, alpha 16, dropout 0.05 on Q/V projections. CUDA training uses BF16 and SDPA. Budget: full-input warmup, sampled adaptation, full evaluation.

## Reproduce and inspect

Run these commands from the project directory after preparing the three original processed catalogs, chronological interactions, TRAIN reviews and frozen CLIP image features using the baseline workflow in `README.md`. The code ZIP excludes raw data, model weights and feature caches; it is not a self-contained copy of those assets. Preserve an original baseline snapshot before any upgrade and keep its recorded hash inventory; do not replace that inventory after changing files.

```bash
python -m pip install -r requirements-qwen.txt
python scripts/download_qwen.py

# Real GPU work must run within an allocated PBS job.
qsub scripts/qwen_train.pbs

# Local serving uses exported 128d towers and the small user head.
# It does not require loading the 0.6B language model at demo time.
./启动演示.command

python scripts/baseline_snapshot.py verify --root . \
  --snapshot experiments/qwen/baseline_before.json \
  > experiments/qwen/baseline_verification.pending.json &&
mv experiments/qwen/baseline_verification.pending.json \
  experiments/qwen/baseline_verification.json
python scripts/make_qwen_report.py --root . --verify-cache-files

# Inspect candidates before writing a new, separately named course archive.
python scripts/build_qwen_submission.py --root .
python scripts/build_qwen_submission.py --root . --write
```

Check that baseline verification reports `unchanged: true`, and that the report reports `complete: true`, 27 records and zero audit errors before using the final results. The archive builder separately requires the audited result matrix and finished presentation/narration materials. It creates a local archive only.

The PBS template is specific to the already configured course environment; inspect allocation policies before reuse. Training writes recoverable optimizer/RNG checkpoints. A formal unit becomes available to the UI only after its selected export, test result and `complete.json` exist. Diagnostic fixtures and incomplete units cannot enter the formal matrix. Job status lives under `experiments/qwen/jobs/`.

Expected final matrix: 3 domains × 3 objectives × 3 independent full-pipeline seeds = 27 Qwen test records. The report generator checks the actual matrix, provenance, gradient routing and cache parity before declaring completion. A negative result remains a result; no improvement is assumed in advance.

The run history includes one result-writing failure. The first Baby frozen checkpoint's unsaved test evaluation was recomputed after fixing device serialization; its selected training checkpoint and training configuration were reused. This was not test-based model selection. The actual recovery is recorded in `experiments/qwen/recovery_note.json`, alongside both job environments and logs.

A later Clothing semantic run stopped on a nonfinite loss. An isolated GPU replay located nonfinite LoRA gradients at step 69 despite finite forward values and head gradients. The same clean state, batch and RNG failed again under automatic SDPA, while MATH replay and a fresh 100-step MATH prefix remained finite. The production embedding function passed both GPU regressions after restricting live CUDA training to MATH SDPA and rejecting nonfinite gradients before an optimizer update. This establishes a backend-dependent numerical failure; it does not identify a particular fused-kernel defect.

The completed 19 units were preserved. The failed Clothing semantic unit had no intermediate checkpoint and restarted from the shared warmup; diagnostic weights are never used for formal training. Both Clothing LoRA objectives use MATH training SDPA, while the completed Baby/Sports runs retain their original automatic backend. Evaluation/cache encoding remains automatic. Objectives, samples, learning rates and budgets did not change, but numerical trajectories are not asserted bitwise equal. The report checks actual completion and the recorded numerical policy before treating the recovery as complete.

A fresh run of the current source uses MATH for all live CUDA candidate training. Original automatic-dispatch sources and their hashes are preserved under `experiments/qwen/diagnostics/93023.gaas/original_source/` for inspection of the earlier measured runs. Reproduction should state the source version and numerical backend rather than treating the historical mixed-backend matrix as a fresh all-MATH run.

## Course submission boundaries

Record a real human narration within the course time limit, supply actual member contributions and signatures, and complete the official AI declaration and peer evaluation. Project code and measured results do not replace those personal requirements. No school submission or publishing is performed by the experiment scripts.
